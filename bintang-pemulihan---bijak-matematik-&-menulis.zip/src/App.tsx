import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Trophy,
  Award,
  Eye,
  GraduationCap,
  Volume2,
  Star,
  CheckCircle,
  HelpCircle,
  BookOpen,
  Layers,
  PenTool,
  MessageSquare,
  Gift,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';

import {
  StudentProfile,
  LevelType,
  TextSizeMode,
  ContrastMode,
  FontMode,
  Badge,
  LeaderboardEntry
} from './types';
import { INITIAL_BADGES, INITIAL_LEADERBOARD } from './data/curriculumData';
import { speechService } from './utils/speech';

import { PraNomborActivity } from './components/PraNomborActivity';
import { MembilangActivity } from './components/MembilangActivity';
import { WritingCanvas } from './components/WritingCanvas';
import { SukuKataActivity } from './components/SukuKataActivity';
import { GamificationModal } from './components/GamificationModal';
import { AccessibilityModal } from './components/AccessibilityModal';
import { TeacherDashboard } from './components/TeacherDashboard';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'pra-nombor' | 'matematik' | 'menulis' | 'sukukata' | 'guru'>('pra-nombor');

  // Accessibility States
  const [textSize, setTextSize] = useState<TextSizeMode>('large'); // Default to 'large' for remedial pupils
  const [contrast, setContrast] = useState<ContrastMode>('default');
  const [fontMode, setFontMode] = useState<FontMode>('comic');
  const [autoSpeak, setAutoSpeak] = useState(true);

  // Modals
  const [isGamificationOpen, setIsGamificationOpen] = useState(false);
  const [gamificationTab, setGamificationTab] = useState<'lencana' | 'papan' | 'peti'>('lencana');
  const [isAccessibilityOpen, setIsAccessibilityOpen] = useState(false);

  // Current Student & Class Profiles
  const [allStudents, setAllStudents] = useState<StudentProfile[]>([
    {
      id: 's1',
      name: 'Adik Danish',
      gender: 'lelaki',
      avatar: '🌟',
      currentLevel: 'tahap1',
      stars: 12,
      xp: 260,
      completedTasksCount: 4,
      unlockedBadges: ['badge-pertama']
    },
    {
      id: 's2',
      name: 'Nurul Aiman',
      gender: 'perempuan',
      avatar: '🧕🏼',
      currentLevel: 'tahap2',
      stars: 21,
      xp: 520,
      completedTasksCount: 9,
      unlockedBadges: ['badge-pertama', 'badge-pra-nombor', 'badge-kira-10']
    },
    {
      id: 's3',
      name: 'Ahmad Daniel',
      gender: 'lelaki',
      avatar: '👦🏽',
      currentLevel: 'tahap3',
      stars: 24,
      xp: 580,
      completedTasksCount: 12,
      unlockedBadges: ['badge-pertama', 'badge-pra-nombor', 'badge-kira-10', 'badge-garis-tiga']
    }
  ]);

  const [currentStudent, setCurrentStudent] = useState<StudentProfile>(allStudents[0]);
  const [badges, setBadges] = useState<Badge[]>(INITIAL_BADGES);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(INITIAL_LEADERBOARD);

  // Welcome speech once on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      speechService.speak(
        'Selamat datang ke Bintang Pemulihan Khas! Mari belajar Matematik dan Menulis bersama Cikgu.'
      );
    }, 600);
    return () => clearTimeout(timer);
  }, []);

  // Handle Tab Switch
  const handleTabChange = (tab: 'pra-nombor' | 'matematik' | 'menulis' | 'sukukata' | 'guru') => {
    speechService.playClickSound();
    setActiveTab(tab);

    if (autoSpeak) {
      const tabNames: Record<string, string> = {
        'pra-nombor': 'Modul Pra-Nombor. Kenal Objek Tebal, Nipis, Tinggi dan Rendah.',
        'matematik': 'Modul Matematik. Membilang Nombor dan Operasi Asas.',
        'menulis': 'Modul Menulis. Latihan Buku Garis Tiga KPM.',
        'sukukata': 'Modul Suku Kata. Latihan Sebutan Fonik Bahasa Melayu.',
        'guru': 'Mod Cikgu Pemulihan. Pantauan dan Lembaran Kerja Boleh Cetak.'
      };
      speechService.speak(tabNames[tab]);
    }
  };

  // Award XP and Stars
  const handleEarnRewards = (earnedXp: number, earnedStars: number) => {
    setCurrentStudent((prev) => {
      const newStars = prev.stars + earnedStars;
      const newXp = prev.xp + earnedXp;

      // Check badges unlock
      const updatedBadges = badges.map((b) => {
        if (!b.unlocked) {
          if (b.id === 'badge-pra-nombor' && activeTab === 'pra-nombor') {
            return { ...b, unlocked: true, unlockedAt: 'Terkini' };
          }
          if (b.id === 'badge-kira-10' && activeTab === 'matematik') {
            return { ...b, unlocked: true, unlockedAt: 'Terkini' };
          }
          if (b.id === 'badge-garis-tiga' && activeTab === 'menulis') {
            return { ...b, unlocked: true, unlockedAt: 'Terkini' };
          }
          if (b.id === 'badge-suku-kata' && activeTab === 'sukukata') {
            return { ...b, unlocked: true, unlockedAt: 'Terkini' };
          }
        }
        return b;
      });
      setBadges(updatedBadges);

      return {
        ...prev,
        stars: newStars,
        xp: newXp,
        completedTasksCount: prev.completedTasksCount + 1
      };
    });

    // Update leaderboard current student
    setLeaderboard((prev) =>
      prev.map((entry) =>
        entry.isCurrentStudent
          ? {
              ...entry,
              stars: entry.stars + earnedStars,
              xp: entry.xp + earnedXp
            }
          : entry
      )
    );
  };

  // Contrast Styling Wrappers
  const getContrastClasses = () => {
    switch (contrast) {
      case 'high-contrast-yellow':
        return 'bg-amber-100/90 text-slate-950 font-semibold';
      case 'high-contrast-dark':
        return 'bg-slate-950 text-yellow-300 font-bold';
      default:
        return 'bg-gradient-to-b from-amber-50/70 via-sky-50/40 to-emerald-50/60 text-slate-800';
    }
  };

  const getFontFamilyClass = () => {
    return fontMode === 'lexend' ? "font-['Lexend',sans-serif]" : "font-['Comic_Neue',cursive,sans-serif]";
  };

  const getTextScaleClass = () => {
    switch (textSize) {
      case 'extralarge':
        return 'text-lg';
      case 'large':
        return 'text-base';
      default:
        return 'text-sm';
    }
  };

  return (
    <div className={`min-h-screen ${getContrastClasses()} ${getFontFamilyClass()} ${getTextScaleClass()} transition-colors duration-200`}>
      {/* Top Header / Bar Pengemudian Utama */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-4 border-amber-300 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Logo & School Badge */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 border-2 border-amber-600 flex items-center justify-center text-3xl shadow-md transform hover:rotate-6 transition">
              ⭐
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-black text-xl sm:text-2xl text-slate-900 leading-tight tracking-tight">
                  Bintang Pemulihan
                </h1>
                <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-md uppercase">
                  KPM
                </span>
              </div>
              <p className="text-xs font-bold text-amber-700">
                Pendidikan Pemulihan Khas Matematik & Menulis
              </p>
            </div>
          </div>

          {/* Gamification Counters & Quick Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Murid Profile pill */}
            <div className="hidden sm:flex items-center gap-2 bg-purple-50 border-2 border-purple-200 px-3 py-1.5 rounded-2xl shadow-sm">
              <span className="text-2xl">{currentStudent.avatar}</span>
              <div className="text-left">
                <span className="text-xs font-black text-purple-900 block leading-tight">
                  {currentStudent.name}
                </span>
                <span className="text-[10px] font-bold text-purple-700 uppercase">
                  {currentStudent.currentLevel === 'tahap1'
                    ? 'Tahap 1 (Asas)'
                    : currentStudent.currentLevel === 'tahap2'
                    ? 'Tahap 2 (Sederhana)'
                    : 'Tahap 3 (Pengukuhan)'}
                </span>
              </div>
            </div>

            {/* Stars counter button */}
            <button
              onClick={() => {
                speechService.playClickSound();
                setGamificationTab('lencana');
                setIsGamificationOpen(true);
              }}
              className="cursor-pointer flex items-center gap-1.5 bg-amber-100 hover:bg-amber-200 border-2 border-amber-400 px-3.5 py-1.5 rounded-2xl font-black text-amber-900 text-sm shadow-sm transition hover:scale-105"
              title="Koleksi Bintang & Lencana"
            >
              <Star size={18} className="fill-amber-400 text-amber-600 animate-pulse" />
              <span>{currentStudent.stars} Bintang</span>
            </button>

            {/* Leaderboard button */}
            <button
              onClick={() => {
                speechService.playClickSound();
                setGamificationTab('papan');
                setIsGamificationOpen(true);
              }}
              className="cursor-pointer flex items-center gap-1.5 bg-indigo-100 hover:bg-indigo-200 border-2 border-indigo-400 px-3.5 py-1.5 rounded-2xl font-black text-indigo-900 text-sm shadow-sm transition hover:scale-105"
              title="Papan Pendahulu Kelas"
            >
              <Trophy size={18} className="text-indigo-600" />
              <span className="hidden md:inline">Papan Pendahulu</span>
            </button>

            {/* Accessibility / Vision Settings Button */}
            <button
              onClick={() => {
                speechService.playClickSound();
                setIsAccessibilityOpen(true);
              }}
              className="cursor-pointer flex items-center gap-1.5 bg-blue-100 hover:bg-blue-200 border-2 border-blue-400 px-3.5 py-1.5 rounded-2xl font-black text-blue-900 text-sm shadow-sm transition hover:scale-105"
              title="Tetapan Penglihatan & Saiz Tulisan"
            >
              <Eye size={18} className="text-blue-700" />
              <span className="hidden sm:inline">Penglihatan</span>
            </button>

            {/* Teacher Dashboard Switcher */}
            <button
              onClick={() => handleTabChange('guru')}
              className={`cursor-pointer flex items-center gap-1.5 border-2 px-3.5 py-1.5 rounded-2xl font-black text-sm shadow-sm transition hover:scale-105 ${
                activeTab === 'guru'
                  ? 'bg-purple-600 text-white border-purple-700 shadow-md'
                  : 'bg-purple-100 hover:bg-purple-200 text-purple-900 border-purple-400'
              }`}
              title="Mod Cikgu Pemulihan & Lembaran Kerja"
            >
              <GraduationCap size={18} />
              <span className="hidden md:inline">Mod Guru</span>
            </button>
          </div>
        </div>

        {/* Primary Subject Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-2 pb-3 overflow-x-auto scrollbar-none">
          <nav className="flex items-center gap-2 sm:gap-3 min-w-max">
            {/* Tab 1: Pra-Nombor (Kenal Objek - As from uploaded image) */}
            <button
              onClick={() => handleTabChange('pra-nombor')}
              className={`cursor-pointer px-4 sm:px-5 py-2.5 rounded-2xl font-black text-base flex items-center gap-2 transition-all ${
                activeTab === 'pra-nombor'
                  ? 'bg-emerald-500 text-white shadow-lg border-2 border-emerald-600 scale-102 ring-2 ring-emerald-300'
                  : 'bg-white hover:bg-emerald-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-xl">📏</span>
              <span>1. Pra-Nombor (Kenal Objek)</span>
            </button>

            {/* Tab 2: Matematik (Membilang & Operasi) */}
            <button
              onClick={() => handleTabChange('matematik')}
              className={`cursor-pointer px-4 sm:px-5 py-2.5 rounded-2xl font-black text-base flex items-center gap-2 transition-all ${
                activeTab === 'matematik'
                  ? 'bg-indigo-600 text-white shadow-lg border-2 border-indigo-700 scale-102 ring-2 ring-indigo-300'
                  : 'bg-white hover:bg-indigo-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-xl">🔢</span>
              <span>2. Matematik & Mengira</span>
            </button>

            {/* Tab 3: Menulis Garis Tiga KPM */}
            <button
              onClick={() => handleTabChange('menulis')}
              className={`cursor-pointer px-4 sm:px-5 py-2.5 rounded-2xl font-black text-base flex items-center gap-2 transition-all ${
                activeTab === 'menulis'
                  ? 'bg-blue-600 text-white shadow-lg border-2 border-blue-700 scale-102 ring-2 ring-blue-300'
                  : 'bg-white hover:bg-blue-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-xl">✍️</span>
              <span>3. Menulis Garis Tiga</span>
            </button>

            {/* Tab 4: Suku Kata & Fonik */}
            <button
              onClick={() => handleTabChange('sukukata')}
              className={`cursor-pointer px-4 sm:px-5 py-2.5 rounded-2xl font-black text-base flex items-center gap-2 transition-all ${
                activeTab === 'sukukata'
                  ? 'bg-rose-500 text-white shadow-lg border-2 border-rose-600 scale-102 ring-2 ring-rose-300'
                  : 'bg-white hover:bg-rose-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-xl">🗣️</span>
              <span>4. Suku Kata & Sebutan</span>
            </button>

            {/* Tab 5: Mod Guru */}
            <button
              onClick={() => handleTabChange('guru')}
              className={`cursor-pointer px-4 sm:px-5 py-2.5 rounded-2xl font-black text-base flex items-center gap-2 transition-all ${
                activeTab === 'guru'
                  ? 'bg-purple-600 text-white shadow-lg border-2 border-purple-700 scale-102 ring-2 ring-purple-300'
                  : 'bg-white hover:bg-purple-50 text-slate-700 border-2 border-slate-200'
              }`}
            >
              <span className="text-xl">🖨️</span>
              <span>Pusat Guru & Lembaran</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Child-Friendly Welcoming Banner */}
        <div className="bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-200 rounded-3xl p-5 border-4 border-amber-400 shadow-md flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="text-4xl sm:text-5xl animate-bounce">🌻</div>
            <div>
              <h2 className="font-black text-slate-900 text-xl sm:text-2xl">
                Hai {currentStudent.name}! Jom Belajar & Kumpul Bintang Hari Ini!
              </h2>
              <p className="text-sm font-bold text-amber-950 mt-0.5">
                Modul Latih Tubi:{' '}
                <span className="bg-white/80 text-amber-900 px-2.5 py-0.5 rounded-full uppercase font-black text-xs">
                  {currentStudent.currentLevel === 'tahap1'
                    ? 'Tahap 1: Penguasaan Asas'
                    : currentStudent.currentLevel === 'tahap2'
                    ? 'Tahap 2: Penguasaan Sederhana'
                    : 'Tahap 3: Pengukuhan Cemerlang'}
                </span>
                {' '}• Tulisan Besar & Butang Suara sedia membantu.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() =>
                speechService.speak(
                  `Hai ${currentStudent.name}! Selamat belajar. Sentuh mana-mana butang audio untuk mendengar arahan cikgu.`
                )
              }
              className="cursor-pointer flex items-center gap-2 bg-white hover:bg-amber-50 text-slate-900 font-extrabold px-4 py-2.5 rounded-2xl border-2 border-amber-400 shadow-sm transition"
            >
              <Volume2 size={20} className="text-amber-600" />
              <span>Dengar Sapaan Cikgu</span>
            </button>
          </div>
        </div>

        {/* Dynamic Activity Render */}
        {activeTab === 'pra-nombor' && (
          <PraNomborActivity onSuccess={handleEarnRewards} textSize={textSize} />
        )}

        {activeTab === 'matematik' && (
          <MembilangActivity onSuccess={handleEarnRewards} textSize={textSize} />
        )}

        {activeTab === 'menulis' && (
          <WritingCanvas onSuccess={handleEarnRewards} textSize={textSize} />
        )}

        {activeTab === 'sukukata' && (
          <SukuKataActivity onSuccess={handleEarnRewards} textSize={textSize} />
        )}

        {activeTab === 'guru' && (
          <TeacherDashboard
            currentStudent={currentStudent}
            onUpdateStudentLevel={(newLevel) => {
              setCurrentStudent((prev) => ({ ...prev, currentLevel: newLevel }));
              setAllStudents((prev) =>
                prev.map((s) => (s.id === currentStudent.id ? { ...s, currentLevel: newLevel } : s))
              );
            }}
            onSelectStudent={(selected) => setCurrentStudent(selected)}
            allStudents={allStudents}
          />
        )}
      </main>

      {/* Footer Info KPM & Accessibility Reminder */}
      <footer className="mt-12 py-8 bg-white/70 border-t-2 border-slate-200 text-center text-xs text-slate-500 font-bold max-w-7xl mx-auto px-4">
        <p>
          Bintang Pemulihan Khas Malaysia • Berdasarkan Standard Kurikulum Pemulihan Khas KPM (Bahasa Melayu & Matematik)
        </p>
        <p className="mt-1 text-slate-400">
          Sesuai untuk kegunaan murid MBK, masalah pembelajaran, disleksia dan masalah penglihatan (Low Vision Support).
        </p>
      </footer>

      {/* Gamification Modal */}
      <GamificationModal
        isOpen={isGamificationOpen}
        onClose={() => setIsGamificationOpen(false)}
        badges={badges}
        leaderboard={leaderboard}
        currentStudentStars={currentStudent.stars}
        currentStudentXp={currentStudent.xp}
        defaultTab={gamificationTab}
      />

      {/* Accessibility Modal */}
      <AccessibilityModal
        isOpen={isAccessibilityOpen}
        onClose={() => setIsAccessibilityOpen(false)}
        textSize={textSize}
        setTextSize={setTextSize}
        contrast={contrast}
        setContrast={setContrast}
        fontMode={fontMode}
        setFontMode={setFontMode}
        autoSpeak={autoSpeak}
        setAutoSpeak={setAutoSpeak}
      />
    </div>
  );
}
