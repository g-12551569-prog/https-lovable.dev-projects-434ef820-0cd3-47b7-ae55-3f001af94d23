import { Badge, LeaderboardEntry, PraNomborItem, MathCountingItem, MathOperationItem, SukuKataItem, TracingTarget } from '../types';

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'badge-pertama',
    title: 'Bintang Pertama',
    description: 'Menyelesaikan tugasan latih tubi pertama dengan jayanya!',
    icon: '⭐',
    unlocked: true,
    unlockedAt: 'Hari ini',
    category: 'keseluruhan'
  },
  {
    id: 'badge-pra-nombor',
    title: 'Pakar Pra-Nombor',
    description: 'Berjaya membezakan konsep tebal, nipis, tinggi dan rendah!',
    icon: '📏',
    unlocked: false,
    category: 'matematik'
  },
  {
    id: 'badge-kira-10',
    title: 'Jaguh Mengira 1-10',
    description: 'Mahir membilang objek hingga 10 tanpa tersilap!',
    icon: '🔢',
    unlocked: false,
    category: 'matematik'
  },
  {
    id: 'badge-tambah-tolak',
    title: 'Wira Operasi Asas',
    description: 'Menyelesaikan soalan tambah dan tolak dengan cemerlang!',
    icon: '➕',
    unlocked: false,
    category: 'matematik'
  },
  {
    id: 'badge-garis-tiga',
    title: 'Juara Tulisan Cantik',
    description: 'Menulis huruf di dalam buku garis tiga dengan sangat kemas!',
    icon: '✍️',
    unlocked: false,
    category: 'menulis'
  },
  {
    id: 'badge-suku-kata',
    title: 'Pakar Suku Kata KV',
    description: 'Berjaya mencantum dan membunyikan suku kata dengan tepat!',
    icon: '🗣️',
    unlocked: false,
    category: 'menulis'
  },
  {
    id: 'badge-rajin',
    title: 'Anak Rajin Pemulihan',
    description: 'Menyiapkan 5 modul pembelajaran secara tekun!',
    icon: '🎖️',
    unlocked: false,
    category: 'kehadiran'
  },
  {
    id: 'badge-juara-khas',
    title: 'Bintang Cemerlang Khas',
    description: 'Mencapai 500 XP dan menguasai semua kemahiran teras!',
    icon: '👑',
    unlocked: false,
    category: 'keseluruhan'
  }
];

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', name: 'Ahmad Daniel', avatar: '👦🏽', stars: 24, xp: 580, levelTitle: 'Tahap 3 - Pengukuhan' },
  { id: '2', name: 'Nurul Iman', avatar: '🧕🏼', stars: 21, xp: 520, levelTitle: 'Tahap 3 - Pengukuhan' },
  { id: '3', name: 'Danish Haziq', avatar: '🧒🏻', stars: 18, xp: 440, levelTitle: 'Tahap 2 - Sederhana' },
  { id: 'current', name: 'Murid Cemerlang (Anda)', avatar: '🌟', stars: 12, xp: 260, levelTitle: 'Tahap 1 - Asas', isCurrentStudent: true },
  { id: '5', name: 'Mei Ling', avatar: '👧🏻', stars: 11, xp: 230, levelTitle: 'Tahap 1 - Asas' },
  { id: '6', name: 'Thiban Kumar', avatar: '👦🏾', stars: 9, xp: 190, levelTitle: 'Tahap 1 - Asas' },
  { id: '7', name: 'Siti Alya', avatar: '👧🏽', stars: 7, xp: 150, levelTitle: 'Tahap 1 - Asas' }
];

// Data Modul Pra-Nombor berasaskan Buku Aktiviti Pemulihan Khas KPM (Gambar Uploaded)
export const PRA_NOMBOR_ITEMS: PraNomborItem[] = [
  {
    id: 'pn-1',
    title: 'Kenal Objek: Tebal dan Nipis',
    category: 'tebal-nipis',
    instruction: 'Pilih objek yang TEBAL',
    voiceInstruction: 'Sila sentuh atau klik pada objek yang tebal.',
    pair: {
      itemA: {
        name: 'Buku Kamus Tebal',
        label: 'Tebal',
        attribute: 'tebal',
        svgType: 'book-thick'
      },
      itemB: {
        name: 'Buku Nota Nipis',
        label: 'Nipis',
        attribute: 'nipis',
        svgType: 'book-thin'
      }
    },
    correctAttribute: 'tebal'
  },
  {
    id: 'pn-2',
    title: 'Kenal Objek: Tebal dan Nipis',
    category: 'tebal-nipis',
    instruction: 'Pilih objek yang NIPIS',
    voiceInstruction: 'Sila sentuh atau klik pada objek yang nipis.',
    pair: {
      itemA: {
        name: 'Papan Kayu Tebal',
        label: 'Tebal',
        attribute: 'tebal',
        svgType: 'plank-thick'
      },
      itemB: {
        name: 'Papan Kayu Nipis',
        label: 'Nipis',
        attribute: 'nipis',
        svgType: 'plank-thin'
      }
    },
    correctAttribute: 'nipis'
  },
  {
    id: 'pn-3',
    title: 'Kenal Objek: Tebal dan Nipis (Makanan)',
    category: 'tebal-nipis',
    instruction: 'Pilih burger yang TEBAL',
    voiceInstruction: 'Sila pilih burger yang tebal.',
    pair: {
      itemA: {
        name: 'Burger Tebal Bertingkat',
        label: 'Tebal',
        attribute: 'tebal',
        svgType: 'burger-thick'
      },
      itemB: {
        name: 'Burger Nipis Biasa',
        label: 'Nipis',
        attribute: 'nipis',
        svgType: 'burger-thin'
      }
    },
    correctAttribute: 'tebal'
  },
  {
    id: 'pn-4',
    title: 'Kenal Objek: Tebal dan Nipis (Kek)',
    category: 'tebal-nipis',
    instruction: 'Pilih potongan kek yang NIPIS',
    voiceInstruction: 'Sila sentuh kek yang nipis.',
    pair: {
      itemA: {
        name: 'Kek Lapis Tebal',
        label: 'Tebal',
        attribute: 'tebal',
        svgType: 'cake-thick'
      },
      itemB: {
        name: 'Kek Lapis Nipis',
        label: 'Nipis',
        attribute: 'nipis',
        svgType: 'cake-thin'
      }
    },
    correctAttribute: 'nipis'
  },
  {
    id: 'pn-5',
    title: 'Kenal Objek: Tinggi dan Rendah',
    category: 'tinggi-rendah',
    instruction: 'Pilih tiang bendera yang TINGGI',
    voiceInstruction: 'Pilih tiang bendera yang lebih tinggi.',
    pair: {
      itemA: {
        name: 'Tiang Bendera Tinggi',
        label: 'Tinggi',
        attribute: 'tinggi',
        svgType: 'flag-tall'
      },
      itemB: {
        name: 'Tiang Bendera Rendah',
        label: 'Rendah',
        attribute: 'rendah',
        svgType: 'flag-short'
      }
    },
    correctAttribute: 'tinggi'
  },
  {
    id: 'pn-6',
    title: 'Kenal Objek: Tinggi dan Rendah (Perabot)',
    category: 'tinggi-rendah',
    instruction: 'Pilih almari yang RENDAH',
    voiceInstruction: 'Sentuh almari yang lebih rendah.',
    pair: {
      itemA: {
        name: 'Almari Pakaian Tinggi',
        label: 'Tinggi',
        attribute: 'tinggi',
        svgType: 'wardrobe-tall'
      },
      itemB: {
        name: 'Almari Kecil Rendah',
        label: 'Rendah',
        attribute: 'rendah',
        svgType: 'wardrobe-short'
      }
    },
    correctAttribute: 'rendah'
  },
  {
    id: 'pn-7',
    title: 'Kenal Objek: Tinggi dan Rendah (Tumbuhan)',
    category: 'tinggi-rendah',
    instruction: 'Pilih pokok yang TINGGI',
    voiceInstruction: 'Sentuh pokok kelapa yang tinggi.',
    pair: {
      itemA: {
        name: 'Pokok Kelapa Tinggi',
        label: 'Tinggi',
        attribute: 'tinggi',
        svgType: 'tree-coconut-tall'
      },
      itemB: {
        name: 'Pokok Pisang Rendah',
        label: 'Rendah',
        attribute: 'rendah',
        svgType: 'tree-banana-short'
      }
    },
    correctAttribute: 'tinggi'
  },
  {
    id: 'pn-8',
    title: 'Kenal Objek: Tinggi dan Rendah (Pasu Bunga)',
    category: 'tinggi-rendah',
    instruction: 'Pilih pasu yang RENDAH',
    voiceInstruction: 'Sentuh pasu yang lebih rendah.',
    pair: {
      itemA: {
        name: 'Pasu Kaca Tinggi',
        label: 'Tinggi',
        attribute: 'tinggi',
        svgType: 'vase-tall'
      },
      itemB: {
        name: 'Pasu Kaca Rendah',
        label: 'Rendah',
        attribute: 'rendah',
        svgType: 'vase-short'
      }
    },
    correctAttribute: 'rendah'
  }
];

export const MATH_COUNTING_ITEMS: MathCountingItem[] = [
  {
    id: 'count-1',
    number: 3,
    objectName: 'Epal Merah',
    emoji: '🍎',
    options: [2, 3, 5],
    voicePrompt: 'Kira bilangan buah epal merah di dalam kotak.'
  },
  {
    id: 'count-2',
    number: 5,
    objectName: 'Bintang Kuning',
    emoji: '⭐',
    options: [4, 5, 6],
    voicePrompt: 'Berapakah bilangan bintang yang bersinar ini?'
  },
  {
    id: 'count-3',
    number: 7,
    objectName: 'Ikan Comel',
    emoji: '🐟',
    options: [6, 7, 8],
    voicePrompt: 'Mari membilang berapa ekor ikan comel yang berenang.'
  },
  {
    id: 'count-4',
    number: 4,
    objectName: 'Kereta Mainan',
    emoji: '🚗',
    options: [3, 4, 5],
    voicePrompt: 'Kira kereta mainan ini dengan cermat.'
  },
  {
    id: 'count-5',
    number: 8,
    objectName: 'Bunga Raya',
    emoji: '🌺',
    options: [7, 8, 9],
    voicePrompt: 'Berapakah kuntum bunga raya kebangsaan kita?'
  }
];

export const MATH_OPERATION_ITEMS: MathOperationItem[] = [
  {
    id: 'op-1',
    num1: 2,
    num2: 3,
    operator: '+',
    objectEmoji: '🧁',
    voicePrompt: 'Dua kek cawan tambah tiga kek cawan menjadi berapa?'
  },
  {
    id: 'op-2',
    num1: 4,
    num2: 2,
    operator: '+',
    objectEmoji: '🎈',
    voicePrompt: 'Empat belon tambah dua belon, berapakah jumlahnya?'
  },
  {
    id: 'op-3',
    num1: 5,
    num2: 2,
    operator: '-',
    objectEmoji: '🍓',
    voicePrompt: 'Ada lima strawberi. Dimakan dua. Berapa biji yang tinggal?'
  },
  {
    id: 'op-4',
    num1: 6,
    num2: 3,
    operator: '-',
    objectEmoji: '✏️',
    voicePrompt: 'Ada enam batang pensel, tolak tiga batang pensel. Berapakah baki?'
  }
];

export const SUKU_KATA_ITEMS: SukuKataItem[] = [
  {
    id: 'sk-1',
    word: 'baju',
    syllables: ['ba', 'ju'],
    meaningImage: '👕',
    category: 'KV',
    hint: 'Pakaian kemas dipakai di badan.'
  },
  {
    id: 'sk-2',
    word: 'buku',
    syllables: ['bu', 'ku'],
    meaningImage: '📖',
    category: 'KV',
    hint: 'Dibaca untuk menuntut ilmu.'
  },
  {
    id: 'sk-3',
    word: 'bola',
    syllables: ['bo', 'la'],
    meaningImage: '⚽',
    category: 'KV',
    hint: 'Bentuk bulat, disepak di padang.'
  },
  {
    id: 'sk-4',
    word: 'meja',
    syllables: ['me', 'ja'],
    meaningImage: '🪵',
    category: 'KV',
    hint: 'Tempat meletak buku dan menulis.'
  },
  {
    id: 'sk-5',
    word: 'mata',
    syllables: ['ma', 'ta'],
    meaningImage: '👀',
    category: 'KV',
    hint: 'Deria untuk melihat dunia.'
  },
  {
    id: 'sk-6',
    word: 'gigi',
    syllables: ['gi', 'gi'],
    meaningImage: '🦷',
    category: 'KV',
    hint: 'Putih bersih untuk mengunyah makanan.'
  },
  {
    id: 'sk-7',
    word: 'roti',
    syllables: ['ro', 'ti'],
    meaningImage: '🍞',
    category: 'KV',
    hint: 'Makanan enak disapu jem kaya.'
  },
  {
    id: 'sk-8',
    word: 'topi',
    syllables: ['to', 'pi'],
    meaningImage: '🧢',
    category: 'KV',
    hint: 'Dipakai di kepala elak panas matahari.'
  },
  {
    id: 'sk-9',
    word: 'sudu',
    syllables: ['su', 'du'],
    meaningImage: '🥄',
    category: 'KV',
    hint: 'Digunakan bersama garpu untuk makan.'
  },
  {
    id: 'sk-10',
    word: 'pasu',
    syllables: ['pa', 'su'],
    meaningImage: '🪴',
    category: 'KV',
    hint: 'Bekas tanaman pokok bunga.'
  }
];

export const TRACING_TARGETS: TracingTarget[] = [
  {
    id: 'trace-a',
    charOrWord: 'a',
    type: 'huruf',
    category: 'vokal',
    instruction: 'Surih huruf kecil "a" di dalam garis biru tengah.',
    guideDots: [
      { x: 180, y: 150 },
      { x: 140, y: 170 },
      { x: 140, y: 220 },
      { x: 180, y: 240 },
      { x: 210, y: 210 },
      { x: 210, y: 150 },
      { x: 210, y: 250 }
    ]
  },
  {
    id: 'trace-b',
    charOrWord: 'b',
    type: 'huruf',
    category: 'konsonan',
    instruction: 'Tarik tiang dari garis merah atas hingga biru bawah, kemudian buat perut buncit di tengah!',
    guideDots: [
      { x: 140, y: 70 },
      { x: 140, y: 150 },
      { x: 140, y: 250 },
      { x: 180, y: 160 },
      { x: 210, y: 200 },
      { x: 180, y: 250 },
      { x: 140, y: 250 }
    ]
  },
  {
    id: 'trace-d',
    charOrWord: 'd',
    type: 'huruf',
    category: 'konsonan',
    instruction: 'Buat bulan sabit dulu di ruang biru, barulah tarik tiang tegak dari atas!',
    guideDots: [
      { x: 190, y: 160 },
      { x: 150, y: 190 },
      { x: 150, y: 220 },
      { x: 190, y: 250 },
      { x: 190, y: 70 },
      { x: 190, y: 250 }
    ]
  },
  {
    id: 'trace-m',
    charOrWord: 'm',
    type: 'huruf',
    category: 'konsonan',
    instruction: 'Tarik tiang pendek, lompat satu bukit, dan lompat bukit kedua!',
    guideDots: [
      { x: 120, y: 160 },
      { x: 120, y: 250 },
      { x: 150, y: 160 },
      { x: 180, y: 200 },
      { x: 180, y: 250 },
      { x: 210, y: 160 },
      { x: 240, y: 200 },
      { x: 240, y: 250 }
    ]
  },
  {
    id: 'trace-ibu',
    charOrWord: 'ibu',
    type: 'perkataan',
    category: 'perkataan-kv',
    instruction: 'Tulis perkataan "ibu" yang disayangi dengan kemas.',
    guideDots: [
      { x: 100, y: 180 },
      { x: 160, y: 180 },
      { x: 220, y: 180 }
    ]
  },
  {
    id: 'trace-bola',
    charOrWord: 'bola',
    type: 'perkataan',
    category: 'perkataan-kv',
    instruction: 'Surih perkataan "bola" mengikut ukuran garis tiga.',
    guideDots: [
      { x: 80, y: 180 },
      { x: 130, y: 180 },
      { x: 180, y: 180 },
      { x: 230, y: 180 }
    ]
  }
];

export const PHONIC_SOUNDS = [
  { syllable: 'ba', example: 'baju', icon: '👕' },
  { syllable: 'bi', example: 'biru', icon: '🟦' },
  { syllable: 'bu', example: 'buku', icon: '📖' },
  { syllable: 'ca', example: 'cawan', icon: '☕' },
  { syllable: 'ci', example: 'ciku', icon: '🥔' },
  { syllable: 'cu', example: 'cuka', icon: '🍶' },
  { syllable: 'da', example: 'dadu', icon: '🎲' },
  { syllable: 'di', example: 'duri', icon: '🌵' },
  { syllable: 'du', example: 'duit', icon: '🪙' },
  { syllable: 'ka', example: 'kayu', icon: '🪵' },
  { syllable: 'ki', example: 'kipas', icon: '🌀' },
  { syllable: 'ku', example: 'kuda', icon: '🐎' },
  { syllable: 'ma', example: 'mata', icon: '👁️' },
  { syllable: 'mi', example: 'mi segera', icon: '🍜' },
  { syllable: 'mu', example: 'muka', icon: '😊' },
  { syllable: 'ra', example: 'raga', icon: '🧺' },
  { syllable: 'ri', example: 'ribut', icon: '🌪️' },
  { syllable: 'ro', example: 'roti', icon: '🍞' }
];
