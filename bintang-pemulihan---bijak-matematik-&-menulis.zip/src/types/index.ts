export type LevelType = 'tahap1' | 'tahap2' | 'tahap3';

export type TextSizeMode = 'normal' | 'large' | 'extralarge';
export type ContrastMode = 'default' | 'high-contrast-yellow' | 'high-contrast-dark';
export type FontMode = 'comic' | 'lexend';

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  category: 'matematik' | 'menulis' | 'kehadiran' | 'keseluruhan';
}

export interface StudentProfile {
  id: string;
  name: string;
  gender: 'lelaki' | 'perempuan';
  avatar: string;
  currentLevel: LevelType;
  stars: number;
  xp: number;
  completedTasksCount: number;
  unlockedBadges: string[];
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  stars: number;
  xp: number;
  levelTitle: string;
  isCurrentStudent?: boolean;
}

export interface PraNomborItem {
  id: string;
  title: string;
  category: 'tebal-nipis' | 'tinggi-rendah' | 'panjang-pendek' | 'banyak-sedikit';
  instruction: string;
  voiceInstruction: string;
  pair: {
    itemA: {
      name: string;
      label: string;
      attribute: string;
      svgType: string;
    };
    itemB: {
      name: string;
      label: string;
      attribute: string;
      svgType: string;
    };
  };
  correctAttribute: string; // which attribute is being asked for
}

export interface MathCountingItem {
  id: string;
  number: number;
  objectName: string;
  emoji: string;
  options: number[];
  voicePrompt: string;
}

export interface MathOperationItem {
  id: string;
  num1: number;
  num2: number;
  operator: '+' | '-';
  objectEmoji: string;
  voicePrompt: string;
}

export interface SukuKataItem {
  id: string;
  word: string;
  syllables: string[];
  meaningImage: string;
  category: 'KV' | 'KVK' | 'KVKK';
  hint: string;
}

export interface TracingTarget {
  id: string;
  charOrWord: string;
  type: 'huruf' | 'perkataan';
  category: 'vokal' | 'konsonan' | 'perkataan-kv' | 'nombor';
  guideDots: { x: number; y: number }[];
  instruction: string;
}
