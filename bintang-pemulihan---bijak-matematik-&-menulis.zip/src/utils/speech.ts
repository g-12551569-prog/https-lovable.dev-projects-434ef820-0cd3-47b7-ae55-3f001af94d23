/**
 * Modul Suara Sebutan Bahasa Melayu Malaysia (Standard ms-MY)
 * Serta Sintesis Audio FX (Web Audio API) tanpa fail audio luaran.
 */

class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private audioCtx: AudioContext | null = null;
  private malaysianVoice: SpeechSynthesisVoice | null = null;
  private voicesLoaded: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.initVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.initVoices();
      }
    }
  }

  private initVoices() {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    // Prioritize ms-MY (Malay Malaysia) over id-ID (Indonesian)
    const msVoice = voices.find(
      (v) => v.lang === 'ms-MY' || v.lang === 'ms_MY' || v.lang === 'ms'
    );
    if (msVoice) {
      this.malaysianVoice = msVoice;
    } else {
      // If no direct ms-MY, find any starting with 'ms'
      const fallbackMs = voices.find((v) => v.lang.toLowerCase().startsWith('ms'));
      this.malaysianVoice = fallbackMs || null;
    }
    this.voicesLoaded = true;
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.audioCtx = new AudioCtx();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Sebut teks dalam Bahasa Melayu Malaysia yang jelas dan tenang untuk murid pemulihan
   */
  public speak(text: string, onEnd?: () => void, rate: number = 0.85): void {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    try {
      this.synth.cancel(); // Stop any pending speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = rate; // Sedikit perlahan agar murid pemulihan & masalah pendengaran/penglihatan dapat tangkap
      utterance.pitch = 1.05; // Mesra kanak-kanak
      utterance.lang = 'ms-MY';

      if (this.malaysianVoice) {
        utterance.voice = this.malaysianVoice;
      }

      utterance.onend = () => {
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        if (onEnd) onEnd();
      };

      this.synth.speak(utterance);
    } catch {
      if (onEnd) onEnd();
    }
  }

  /**
   * Sebut ejaan suku kata berturutan (contoh: "b... a... ba!")
   */
  public spellSyllable(syllable: string, onEnd?: () => void): void {
    // Break into phonetic pieces if 2 characters: e.g. "ba" -> "b... a... ba"
    let spokenText = syllable;
    if (syllable.length === 2) {
      spokenText = `${syllable[0]}. ${syllable[1]}. ${syllable}.`;
    } else if (syllable.length === 3) {
      spokenText = `${syllable[0]}. ${syllable[1]}. ${syllable[2]}. ${syllable}.`;
    }
    this.speak(spokenText, onEnd, 0.75);
  }

  public stop(): void {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  // --- Web Audio Synthesizer Effects (Ceria & Mengujakan Murid) ---

  public playSuccessSound(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 (Major arpeggio)
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);

      gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.1);
      gain.gain.linearRampToValueAtTime(0.25, ctx.currentTime + idx * 0.1 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.1);
      osc.stop(ctx.currentTime + idx * 0.1 + 0.4);
    });
  }

  public playStarSound(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(987.77, ctx.currentTime); // B5
    osc.frequency.exponentialRampToValueAtTime(1318.51, ctx.currentTime + 0.15); // E6

    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  }

  public playClickSound(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  }

  public playEncouragementSound(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    // Gentle "Cuba lagi" soft harmonic
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(329.63, ctx.currentTime); // E4
    osc.frequency.exponentialRampToValueAtTime(392.0, ctx.currentTime + 0.15); // G4

    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  }
}

export const speechService = new SpeechService();
