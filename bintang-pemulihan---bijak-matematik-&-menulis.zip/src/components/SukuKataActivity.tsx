import React, { useState } from 'react';
import { Volume2, Sparkles, CheckCircle2, RotateCcw, ArrowRight, Play } from 'lucide-react';
import confetti from 'canvas-confetti';
import { SUKU_KATA_ITEMS, PHONIC_SOUNDS } from '../data/curriculumData';
import { speechService } from '../utils/speech';

interface SukuKataActivityProps {
  onSuccess: (xpEarned: number, starsEarned: number) => void;
  textSize: string;
}

export const SukuKataActivity: React.FC<SukuKataActivityProps> = ({ onSuccess, textSize }) => {
  const [subTab, setSubTab] = useState<'cantum' | 'carta'>('cantum');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [assembledSyllables, setAssembledSyllables] = useState<string[]>([]);
  const [availableSyllables, setAvailableSyllables] = useState<string[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);

  const currentItem = SUKU_KATA_ITEMS[currentIndex];

  // Initialize available shuffled syllables for the word + distractors
  React.useEffect(() => {
    if (currentItem) {
      // Pick 1-2 random distractors from other words
      const otherSyllables = SUKU_KATA_ITEMS.flatMap((i) => i.syllables).filter(
        (s) => !currentItem.syllables.includes(s)
      );
      const distractors = otherSyllables.slice(0, 2);
      const combined = [...currentItem.syllables, ...distractors].sort(() => Math.random() - 0.5);
      setAvailableSyllables(combined);
      setAssembledSyllables([]);
      setIsCompleted(false);

      // Voice prompt introduction
      speechService.speak(
        `Susun suku kata untuk mengeja perkataan bagi gambar ini: ${currentItem.word}.`
      );
    }
  }, [currentIndex]);

  const handlePickSyllable = (syl: string, indexInAvailable: number) => {
    speechService.playClickSound();
    speechService.spellSyllable(syl);

    const newAssembled = [...assembledSyllables, syl];
    setAssembledSyllables(newAssembled);

    // Remove picked item from available
    const newAvail = [...availableSyllables];
    newAvail.splice(indexInAvailable, 1);
    setAvailableSyllables(newAvail);

    // Check if word is completed
    const assembledWord = newAssembled.join('');
    if (assembledWord === currentItem.word) {
      setIsCompleted(true);
      speechService.playSuccessSound();
      speechService.speak(
        `Tahniah! Sebutan tepat sekali: ${newAssembled.join(' - ')} ... ${currentItem.word}!`
      );
      confetti({
        particleCount: 65,
        spread: 65,
        origin: { y: 0.6 }
      });
      onSuccess(25, 2);
    } else if (newAssembled.length >= currentItem.syllables.length) {
      // Wrong assembly
      speechService.playEncouragementSound();
      speechService.speak(`Hampir tepat. Jom susun semula suku kata bagi ${currentItem.word}.`);
    }
  };

  const handleReset = () => {
    speechService.playClickSound();
    const otherSyllables = SUKU_KATA_ITEMS.flatMap((i) => i.syllables).filter(
      (s) => !currentItem.syllables.includes(s)
    );
    const distractors = otherSyllables.slice(0, 2);
    setAvailableSyllables([...currentItem.syllables, ...distractors].sort(() => Math.random() - 0.5));
    setAssembledSyllables([]);
    setIsCompleted(false);
  };

  const handleNextWord = () => {
    speechService.playClickSound();
    if (currentIndex < SUKU_KATA_ITEMS.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-4 border-rose-300">
      {/* Sub Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b-2 border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              speechService.playClickSound();
              setSubTab('cantum');
            }}
            className={`cursor-pointer px-5 py-2.5 rounded-2xl font-black text-base transition-all ${
              subTab === 'cantum'
                ? 'bg-rose-500 text-white shadow-lg border-2 border-rose-600'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            🧩 Permainan Cantum Suku Kata
          </button>
          <button
            onClick={() => {
              speechService.playClickSound();
              setSubTab('carta');
            }}
            className={`cursor-pointer px-5 py-2.5 rounded-2xl font-black text-base transition-all ${
              subTab === 'carta'
                ? 'bg-rose-500 text-white shadow-lg border-2 border-rose-600'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            🗣️ Carta Sebutan Fonik Malaysia
          </button>
        </div>

        {subTab === 'cantum' && (
          <button
            onClick={() =>
              speechService.speak(
                `Gambar ini ialah ${currentItem.word}. Sila cantumkan suku kata untuk membentuk perkataan ${currentItem.word}.`
              )
            }
            className="cursor-pointer flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold px-4 py-2 rounded-2xl shadow transition"
          >
            <Volume2 size={22} />
            <span>Dengar Suara Cikgu</span>
          </button>
        )}
      </div>

      {/* SubTab 1: Cantum Suku Kata */}
      {subTab === 'cantum' && (
        <div>
          {/* Card Showcase */}
          <div className="bg-gradient-to-b from-rose-50 to-amber-50 rounded-3xl p-6 text-center border-2 border-rose-200 mb-8 max-w-2xl mx-auto">
            <div className="text-7xl sm:text-8xl my-3 filter drop-shadow">{currentItem.meaningImage}</div>
            <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Perkataan KPM: Suku Kata Terbuka (KV)</p>
            <p className="text-slate-700 font-semibold text-lg italic mt-1">{currentItem.hint}</p>

            {/* Assembled Word Slots */}
            <div className="flex items-center justify-center gap-3 my-6">
              {currentItem.syllables.map((_, idx) => {
                const filledSyllable = assembledSyllables[idx];
                return (
                  <div
                    key={idx}
                    className={`w-28 sm:w-36 h-20 rounded-2xl border-4 flex items-center justify-center text-3xl sm:text-4xl font-black shadow-md transition-all ${
                      filledSyllable
                        ? 'bg-emerald-500 text-white border-emerald-600 scale-105'
                        : 'bg-white border-dashed border-rose-300 text-slate-300'
                    }`}
                  >
                    {filledSyllable ? (
                      <button
                        onClick={() => speechService.spellSyllable(filledSyllable)}
                        className="cursor-pointer hover:underline flex items-center gap-1"
                        title="Klik untuk sebut semula"
                      >
                        {filledSyllable}
                      </button>
                    ) : (
                      '___'
                    )}
                  </div>
                );
              })}
            </div>

            {/* Whole Word Preview & Speaker */}
            {isCompleted && (
              <div className="animate-bounce">
                <button
                  onClick={() => speechService.speak(currentItem.word)}
                  className="cursor-pointer inline-flex items-center gap-2 bg-white px-6 py-2.5 rounded-full border-2 border-emerald-400 text-emerald-800 font-black text-2xl shadow-md"
                >
                  <Volume2 size={26} className="text-emerald-600" />
                  <span>{currentItem.word.toUpperCase()}</span>
                </button>
              </div>
            )}
          </div>

          {/* Available Syllable Options */}
          {!isCompleted && (
            <div>
              <p className="text-center font-bold text-slate-700 mb-4 text-lg">
                Sentuh suku kata di bawah untuk dimasukkan ke dalam kotak di atas:
              </p>
              <div className="flex flex-wrap justify-center gap-3 sm:gap-4 max-w-xl mx-auto">
                {availableSyllables.map((syl, idx) => (
                  <button
                    key={`${syl}-${idx}`}
                    onClick={() => handlePickSyllable(syl, idx)}
                    className="cursor-pointer px-6 py-4 rounded-3xl bg-white hover:bg-rose-100 text-rose-700 font-black text-3xl sm:text-4xl border-3 border-rose-400 shadow-md hover:scale-105 transition-all duration-150 active:scale-95"
                  >
                    {syl}
                  </button>
                ))}
              </div>

              {assembledSyllables.length > 0 && !isCompleted && (
                <div className="flex justify-center mt-6">
                  <button
                    onClick={handleReset}
                    className="cursor-pointer flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-base border border-slate-300"
                  >
                    <RotateCcw size={18} />
                    <span>Susun Semula</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Selesai / Next button */}
          {isCompleted && (
            <div className="flex justify-center gap-4 mt-6">
              <button
                onClick={handleNextWord}
                className="cursor-pointer flex items-center gap-2 px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xl shadow-lg border-2 border-emerald-700"
              >
                <span>Perkataan Seterusnya</span>
                <ArrowRight size={24} />
              </button>
            </div>
          )}
        </div>
      )}

      {/* SubTab 2: Carta Sebutan Fonik */}
      {subTab === 'carta' && (
        <div>
          <div className="bg-amber-50 p-4 rounded-2xl border-2 border-amber-200 mb-6 text-center">
            <p className="font-extrabold text-amber-900 text-lg">
              Carta Sebutan Suku Kata Terbuka (Bahasa Melayu Malaysia)
            </p>
            <p className="text-sm text-amber-700 font-medium">
              Sentuh mana-mana kad di bawah untuk mendengar sebutan fonik satu persatu.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {PHONIC_SOUNDS.map((item) => (
              <button
                key={item.syllable}
                onClick={() => {
                  speechService.playClickSound();
                  speechService.spellSyllable(item.syllable);
                }}
                className="cursor-pointer p-4 rounded-2xl bg-white hover:bg-rose-50 border-2 border-slate-200 hover:border-rose-400 shadow-sm flex flex-col items-center justify-center transition-all hover:scale-105 group"
              >
                <span className="text-3xl mb-1">{item.icon}</span>
                <span className="font-black text-3xl text-rose-600 group-hover:scale-110 transition-transform">
                  {item.syllable}
                </span>
                <span className="text-xs font-bold text-slate-500 mt-1">{item.example}</span>
                <span className="text-[10px] text-rose-500 font-extrabold uppercase mt-0.5">Tekan Dengar</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
