import React, { useState } from 'react';
import { Volume2, CheckCircle, RotateCcw, ArrowRight, Sparkles, Plus, Minus } from 'lucide-react';
import confetti from 'canvas-confetti';
import { MATH_COUNTING_ITEMS, MATH_OPERATION_ITEMS } from '../data/curriculumData';
import { speechService } from '../utils/speech';

interface MembilangActivityProps {
  onSuccess: (xpEarned: number, starsEarned: number) => void;
  textSize: string;
}

export const MembilangActivity: React.FC<MembilangActivityProps> = ({ onSuccess, textSize }) => {
  const [mode, setMode] = useState<'membilang' | 'operasi'>('membilang');
  const [countIndex, setCountIndex] = useState(0);
  const [opIndex, setOpIndex] = useState(0);
  const [tappedItems, setTappedItems] = useState<number[]>([]);
  const [crossedOutItems, setCrossedOutItems] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const currentCountItem = MATH_COUNTING_ITEMS[countIndex];
  const currentOpItem = MATH_OPERATION_ITEMS[opIndex];

  // Tap an individual object to count aloud
  const handleTapObject = (idx: number) => {
    speechService.playStarSound();
    if (!tappedItems.includes(idx)) {
      const newTapped = [...tappedItems, idx];
      setTappedItems(newTapped);
      const malayNumbers = [
        'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Lapan', 'Sembilan', 'Sepuluh'
      ];
      const countName = malayNumbers[newTapped.length - 1] || `${newTapped.length}`;
      speechService.speak(countName);
    }
  };

  // Toggle cross-out in subtraction mode
  const handleToggleCross = (idx: number) => {
    speechService.playClickSound();
    if (crossedOutItems.includes(idx)) {
      setCrossedOutItems(crossedOutItems.filter((i) => i !== idx));
    } else {
      setCrossedOutItems([...crossedOutItems, idx]);
      speechService.speak('Tolak satu');
    }
  };

  const handleSelectCountAnswer = (ans: number) => {
    if (isAnswered) return;
    speechService.playClickSound();
    setSelectedAnswer(ans);
    setIsAnswered(true);

    const correct = ans === currentCountItem.number;
    setIsCorrect(correct);

    if (correct) {
      speechService.playSuccessSound();
      speechService.speak(
        `Hebat sekali! Betul, ada ${currentCountItem.number} ${currentCountItem.objectName} kesemuanya!`
      );
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.6 }
      });
      onSuccess(20, 1);
    } else {
      speechService.playEncouragementSound();
      speechService.speak(`Hampir tepat! Jom sentuh setiap gambar untuk mengira semula.`);
    }
  };

  const handleSelectOpAnswer = (ans: number) => {
    if (isAnswered) return;
    speechService.playClickSound();
    setSelectedAnswer(ans);
    setIsAnswered(true);

    const correctAnswer =
      currentOpItem.operator === '+'
        ? currentOpItem.num1 + currentOpItem.num2
        : currentOpItem.num1 - currentOpItem.num2;

    const correct = ans === correctAnswer;
    setIsCorrect(correct);

    if (correct) {
      speechService.playSuccessSound();
      speechService.speak(
        `Jawapan kamu tepat! ${currentOpItem.num1} ${
          currentOpItem.operator === '+' ? 'tambah' : 'tolak'
        } ${currentOpItem.num2} sama dengan ${correctAnswer}!`
      );
      confetti({
        particleCount: 65,
        spread: 65,
        origin: { y: 0.6 }
      });
      onSuccess(25, 2);
    } else {
      speechService.playEncouragementSound();
      speechService.speak(`Cuba kira lagi dengan melihat objek di bawah.`);
    }
  };

  const nextCountQuestion = () => {
    speechService.playClickSound();
    if (countIndex < MATH_COUNTING_ITEMS.length - 1) {
      setCountIndex(countIndex + 1);
    } else {
      setCountIndex(0);
    }
    setTappedItems([]);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  const nextOpQuestion = () => {
    speechService.playClickSound();
    if (opIndex < MATH_OPERATION_ITEMS.length - 1) {
      setOpIndex(opIndex + 1);
    } else {
      setOpIndex(0);
    }
    setCrossedOutItems([]);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-4 border-indigo-400">
      {/* Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b-2 border-slate-100">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              speechService.playClickSound();
              setMode('membilang');
              setIsAnswered(false);
            }}
            className={`cursor-pointer px-5 py-2.5 rounded-2xl font-black text-base transition-all ${
              mode === 'membilang'
                ? 'bg-indigo-600 text-white shadow-lg border-2 border-indigo-700'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            🔢 Membilang 1-10
          </button>
          <button
            onClick={() => {
              speechService.playClickSound();
              setMode('operasi');
              setIsAnswered(false);
            }}
            className={`cursor-pointer px-5 py-2.5 rounded-2xl font-black text-base transition-all ${
              mode === 'operasi'
                ? 'bg-indigo-600 text-white shadow-lg border-2 border-indigo-700'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            ➕ Operasi Tambah & Tolak
          </button>
        </div>

        <button
          onClick={() =>
            speechService.speak(
              mode === 'membilang' ? currentCountItem.voicePrompt : currentOpItem.voicePrompt
            )
          }
          className="cursor-pointer flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold px-4 py-2 rounded-2xl shadow transition"
        >
          <Volume2 size={22} />
          <span>Dengar Arahan</span>
        </button>
      </div>

      {/* Mode 1: Membilang */}
      {mode === 'membilang' && (
        <div>
          <div className="bg-indigo-50 border-2 border-indigo-200 rounded-3xl p-6 mb-6 text-center">
            <span className="text-sm font-bold text-indigo-700 uppercase block mb-1">
              Sentuh objek satu demi satu untuk membilang:
            </span>
            <p className={`font-black text-slate-900 ${textSize === 'extralarge' ? 'text-3xl' : 'text-2xl'}`}>
              Berapakah bilangan {currentCountItem.objectName}?
            </p>

            {/* Clickable interactive objects to count */}
            <div className="flex flex-wrap justify-center gap-4 my-8 max-w-xl mx-auto">
              {Array.from({ length: currentCountItem.number }).map((_, idx) => {
                const isTapped = tappedItems.includes(idx);
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleTapObject(idx)}
                    className={`cursor-pointer w-20 h-20 sm:w-24 sm:h-24 rounded-3xl flex flex-col items-center justify-center text-4xl sm:text-5xl transition-all duration-200 border-4 ${
                      isTapped
                        ? 'bg-amber-200 border-amber-500 scale-110 shadow-lg ring-4 ring-yellow-300'
                        : 'bg-white border-slate-300 hover:border-indigo-400 hover:scale-105'
                    }`}
                  >
                    <span>{currentCountItem.emoji}</span>
                    {isTapped && (
                      <span className="text-xs font-black text-amber-900 bg-amber-300 px-2 py-0.5 rounded-full mt-1">
                        {tappedItems.indexOf(idx) + 1}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            <p className="text-sm font-bold text-slate-600">
              {tappedItems.length > 0
                ? `Kamu sudah membilang: ${tappedItems.length} objek`
                : 'Petua: Sentuh gambar di atas untuk membilang satu demi satu!'}
            </p>
          </div>

          {/* Multiple Choice Options */}
          <div className="mt-8">
            <p className="text-center font-bold text-slate-700 mb-3 text-lg">Pilih jawapan yang betul:</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {currentCountItem.options.map((option) => (
                <button
                  key={option}
                  onClick={() => handleSelectCountAnswer(option)}
                  disabled={isAnswered}
                  className={`cursor-pointer py-5 rounded-3xl font-black text-3xl sm:text-4xl transition-all border-4 shadow-md ${
                    selectedAnswer === option
                      ? isCorrect
                        ? 'bg-emerald-500 text-white border-emerald-600 scale-105 ring-4 ring-emerald-300'
                        : 'bg-rose-500 text-white border-rose-600'
                      : 'bg-slate-100 hover:bg-amber-100 text-slate-900 border-slate-300 hover:border-amber-400'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          {/* Post Answer action */}
          {isAnswered && (
            <div className="mt-8 flex justify-center">
              {isCorrect ? (
                <button
                  onClick={nextCountQuestion}
                  className="cursor-pointer flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xl shadow-lg border-2 border-emerald-700"
                >
                  <span>Soalan Seterusnya</span>
                  <ArrowRight size={24} />
                </button>
              ) : (
                <button
                  onClick={() => {
                    speechService.playClickSound();
                    setSelectedAnswer(null);
                    setIsAnswered(false);
                  }}
                  className="cursor-pointer flex items-center gap-2 px-6 py-3 rounded-2xl bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold text-lg shadow"
                >
                  <RotateCcw size={20} />
                  <span>Cuba Sekali Lagi</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Mode 2: Operasi Tambah & Tolak */}
      {mode === 'operasi' && (
        <div>
          <div className="bg-amber-50 border-2 border-amber-300 rounded-3xl p-6 mb-6 text-center">
            <span className="text-sm font-extrabold text-amber-800 uppercase block mb-1">
              {currentOpItem.operator === '+' ? 'Operasi Tambah (Gabungkan Objek)' : 'Operasi Tolak (Keluarkan Objek)'}
            </span>
            <p className={`font-black text-slate-900 ${textSize === 'extralarge' ? 'text-4xl' : 'text-3xl'} my-3`}>
              {currentOpItem.num1} {currentOpItem.operator} {currentOpItem.num2} = ?
            </p>

            {/* Visual Arithmetic Representation */}
            <div className="flex flex-wrap items-center justify-center gap-4 my-6">
              {/* Group 1 */}
              <div className="flex items-center gap-2 bg-white px-5 py-3 rounded-2xl border-2 border-amber-200 shadow-sm">
                {Array.from({ length: currentOpItem.num1 }).map((_, i) => (
                  <span key={i} className="text-3xl sm:text-4xl">
                    {currentOpItem.objectEmoji}
                  </span>
                ))}
                <span className="font-extrabold text-indigo-700 ml-2 text-xl">({currentOpItem.num1})</span>
              </div>

              {/* Operator */}
              <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center font-black text-2xl shadow">
                {currentOpItem.operator === '+' ? <Plus size={28} /> : <Minus size={28} />}
              </div>

              {/* Group 2 */}
              <div className="flex items-center gap-2 bg-white px-5 py-3 rounded-2xl border-2 border-amber-200 shadow-sm">
                {Array.from({ length: currentOpItem.num2 }).map((_, i) => (
                  <span
                    key={i}
                    className={`text-3xl sm:text-4xl ${
                      currentOpItem.operator === '-' ? 'opacity-40 line-through' : ''
                    }`}
                  >
                    {currentOpItem.objectEmoji}
                  </span>
                ))}
                <span className="font-extrabold text-indigo-700 ml-2 text-xl">({currentOpItem.num2})</span>
              </div>
            </div>
          </div>

          {/* Operation Options */}
          <div className="mt-8">
            <p className="text-center font-bold text-slate-700 mb-3 text-lg">Berapakah jawapannya?</p>
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {(() => {
                const correctAns =
                  currentOpItem.operator === '+'
                    ? currentOpItem.num1 + currentOpItem.num2
                    : currentOpItem.num1 - currentOpItem.num2;
                const opts = [correctAns - 1, correctAns, correctAns + 2].sort((a, b) => a - b);
                return opts.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => handleSelectOpAnswer(opt)}
                    disabled={isAnswered}
                    className={`cursor-pointer py-5 rounded-3xl font-black text-3xl sm:text-4xl transition-all border-4 shadow-md ${
                      selectedAnswer === opt
                        ? isCorrect
                          ? 'bg-emerald-500 text-white border-emerald-600 scale-105'
                          : 'bg-rose-500 text-white border-rose-600'
                        : 'bg-slate-100 hover:bg-amber-100 text-slate-900 border-slate-300 hover:border-amber-400'
                    }`}
                  >
                    {opt}
                  </button>
                ));
              })()}
            </div>
          </div>

          {isAnswered && (
            <div className="mt-8 flex justify-center">
              {isCorrect ? (
                <button
                  onClick={nextOpQuestion}
                  className="cursor-pointer flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xl shadow-lg border-2 border-emerald-700"
                >
                  <span>Soalan Seterusnya</span>
                  <ArrowRight size={24} />
                </button>
              ) : (
                <button
                  onClick={() => {
                    speechService.playClickSound();
                    setSelectedAnswer(null);
                    setIsAnswered(false);
                  }}
                  className="cursor-pointer flex items-center gap-2 px-6 py-3 rounded-2xl bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold text-lg shadow"
                >
                  <RotateCcw size={20} />
                  <span>Cuba Semula</span>
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
