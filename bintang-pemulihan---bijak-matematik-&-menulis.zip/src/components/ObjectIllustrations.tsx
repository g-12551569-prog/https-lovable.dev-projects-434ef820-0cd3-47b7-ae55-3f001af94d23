import React from 'react';

interface ObjectIllustrationProps {
  type: string;
  className?: string;
}

export const ObjectIllustration: React.FC<ObjectIllustrationProps> = ({ type, className = 'w-48 h-48' }) => {
  switch (type) {
    // 1. Buku Tebal vs Buku Nipis
    case 'book-thick':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Spine and thick pages */}
          <rect x="25" y="45" width="150" height="90" rx="8" fill="#F8FAFC" stroke="#0F172A" strokeWidth="4" />
          <path d="M25 45 L50 20 L175 20 L150 45 Z" fill="#3B82F6" stroke="#0F172A" strokeWidth="4" />
          <path d="M175 20 L175 105 L150 135 L150 45 Z" fill="#E2E8F0" stroke="#0F172A" strokeWidth="4" />
          {/* Multiple page ridges indicating thickness */}
          <line x1="28" y1="65" x2="148" y2="65" stroke="#94A3B8" strokeWidth="2.5" strokeDasharray="4 2" />
          <line x1="28" y1="85" x2="148" y2="85" stroke="#94A3B8" strokeWidth="2.5" strokeDasharray="4 2" />
          <line x1="28" y1="105" x2="148" y2="105" stroke="#94A3B8" strokeWidth="2.5" strokeDasharray="4 2" />
          <line x1="28" y1="120" x2="148" y2="120" stroke="#94A3B8" strokeWidth="2.5" strokeDasharray="4 2" />
          {/* Book cover front */}
          <rect x="25" y="45" width="125" height="90" rx="6" fill="#60A5FA" stroke="#0F172A" strokeWidth="4" />
          <text x="50" y="80" fill="#FFFFFF" fontWeight="800" fontSize="14" fontFamily="sans-serif">MATEMATIK</text>
          <text x="60" y="112" fill="#FEF08A" fontWeight="900" fontSize="24">➕ ➖ ✖️</text>
          {/* Badge: TEBAL */}
          <rect x="40" y="10" width="70" height="22" rx="6" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
          <text x="55" y="26" fill="#FFFFFF" fontWeight="bold" fontSize="12">TEBAL</text>
        </svg>
      );

    case 'book-thin':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Thin booklet laying flat */}
          <path d="M30 85 L70 50 L170 50 L130 85 Z" fill="#F472B6" stroke="#0F172A" strokeWidth="4" />
          <rect x="30" y="85" width="100" height="16" rx="3" fill="#FDF2F8" stroke="#0F172A" strokeWidth="3.5" />
          <path d="M130 85 L170 50 L170 65 L130 101 Z" fill="#CBD5E1" stroke="#0F172A" strokeWidth="3.5" />
          <line x1="32" y1="94" x2="128" y2="94" stroke="#94A3B8" strokeWidth="1.5" />
          {/* Badge: NIPIS */}
          <rect x="55" y="30" width="60" height="20" rx="6" fill="#10B981" stroke="#047857" strokeWidth="2" />
          <text x="68" y="44" fill="#FFFFFF" fontWeight="bold" fontSize="11">NIPIS</text>
        </svg>
      );

    // 2. Papan Tebal vs Papan Nipis
    case 'plank-thick':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Thick 3D wooden beam */}
          <path d="M30 70 L90 35 L180 45 L120 80 Z" fill="#D97706" stroke="#0F172A" strokeWidth="4" />
          <rect x="30" y="70" width="90" height="60" fill="#B45309" stroke="#0F172A" strokeWidth="4" rx="2" />
          <path d="M120 70 L180 45 L180 105 L120 130 Z" fill="#92400E" stroke="#0F172A" strokeWidth="4" />
          {/* Wood grain lines */}
          <circle cx="75" cy="100" r="14" stroke="#78350F" strokeWidth="2" fill="none" />
          <circle cx="75" cy="100" r="8" stroke="#78350F" strokeWidth="2" fill="none" />
        </svg>
      );

    case 'plank-thin':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Thin wooden plank */}
          <path d="M25 90 L85 60 L180 70 L120 100 Z" fill="#FBBF24" stroke="#0F172A" strokeWidth="3.5" />
          <rect x="25" y="90" width="95" height="12" fill="#D97706" stroke="#0F172A" strokeWidth="3.5" rx="2" />
          <path d="M120 90 L180 70 L180 82 L120 102 Z" fill="#B45309" stroke="#0F172A" strokeWidth="3.5" />
        </svg>
      );

    // 3. Burger Tebal vs Burger Nipis
    case 'burger-thick':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Top bun */}
          <path d="M40 55 C40 25 160 25 160 55 Z" fill="#F59E0B" stroke="#0F172A" strokeWidth="3.5" />
          <circle cx="70" cy="40" r="2" fill="#FEF08A" />
          <circle cx="100" cy="35" r="2" fill="#FEF08A" />
          <circle cx="130" cy="42" r="2" fill="#FEF08A" />
          {/* Lettuce */}
          <path d="M35 55 Q50 65 65 55 Q80 65 95 55 Q110 65 125 55 Q140 65 155 55 Q170 65 165 55" stroke="#16A34A" strokeWidth="7" strokeLinecap="round" />
          {/* Tomato */}
          <rect x="42" y="65" width="116" height="10" rx="4" fill="#EF4444" stroke="#0F172A" strokeWidth="3" />
          {/* Patty 1 */}
          <rect x="38" y="77" width="124" height="14" rx="6" fill="#78350F" stroke="#0F172A" strokeWidth="3.5" />
          {/* Cheese */}
          <polygon points="40,93 160,93 130,105 100,95 70,105" fill="#FACC15" stroke="#CA8A04" strokeWidth="2" />
          {/* Patty 2 */}
          <rect x="38" y="103" width="124" height="14" rx="6" fill="#78350F" stroke="#0F172A" strokeWidth="3.5" />
          {/* Bottom Bun */}
          <path d="M40 120 C40 120 40 142 100 142 C160 142 160 120 160 120 Z" fill="#F59E0B" stroke="#0F172A" strokeWidth="3.5" />
        </svg>
      );

    case 'burger-thin':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Flat simple burger */}
          <path d="M50 82 C50 68 150 68 150 82 Z" fill="#F59E0B" stroke="#0F172A" strokeWidth="3" />
          <rect x="48" y="85" width="104" height="8" rx="3" fill="#78350F" stroke="#0F172A" strokeWidth="2.5" />
          <path d="M50 95 C50 95 50 106 100 106 C150 106 150 95 150 95 Z" fill="#F59E0B" stroke="#0F172A" strokeWidth="3" />
        </svg>
      );

    // 4. Kek Tebal vs Kek Nipis
    case 'cake-thick':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Multi layer tall slice */}
          <polygon points="30,135 170,135 150,70 50,70" fill="#FED7AA" stroke="#0F172A" strokeWidth="3.5" />
          <rect x="38" y="88" width="124" height="8" fill="#F43F5E" />
          <rect x="34" y="110" width="132" height="8" fill="#FFFFFF" />
          <polygon points="50,70 150,70 130,40 70,40" fill="#FFFFFF" stroke="#0F172A" strokeWidth="3" />
          <circle cx="100" cy="30" r="14" fill="#E11D48" stroke="#881337" strokeWidth="3" />
          <polygon points="98,16 102,16 100,10" fill="#15803D" />
        </svg>
      );

    case 'cake-thin':
      return (
        <svg viewBox="0 0 200 160" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Low flat cake slice */}
          <polygon points="35,120 165,120 145,95 55,95" fill="#FED7AA" stroke="#0F172A" strokeWidth="3" />
          <polygon points="55,95 145,95 130,80 70,80" fill="#FFFFFF" stroke="#0F172A" strokeWidth="2.5" />
          <circle cx="100" cy="74" r="8" fill="#E11D48" />
        </svg>
      );

    // 5. Tiang Bendera Tinggi vs Tiang Bendera Rendah
    case 'flag-tall':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <line x1="60" y1="170" x2="60" y2="15" stroke="#0F172A" strokeWidth="6" strokeLinecap="round" />
          <circle cx="60" cy="15" r="7" fill="#F59E0B" stroke="#0F172A" strokeWidth="2.5" />
          {/* Big waving flag */}
          <path d="M63 25 Q100 15 130 30 Q160 45 150 65 Q110 50 63 65 Z" fill="#EF4444" stroke="#0F172A" strokeWidth="3.5" />
          <rect x="40" y="165" width="40" height="12" rx="4" fill="#64748B" stroke="#0F172A" strokeWidth="3" />
        </svg>
      );

    case 'flag-short':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <line x1="80" y1="170" x2="80" y2="95" stroke="#0F172A" strokeWidth="5" strokeLinecap="round" />
          <circle cx="80" cy="95" r="5" fill="#F59E0B" stroke="#0F172A" strokeWidth="2" />
          <path d="M82 102 Q105 95 125 105 Q145 115 135 128 Q110 118 82 128 Z" fill="#3B82F6" stroke="#0F172A" strokeWidth="3" />
          <rect x="65" y="165" width="30" height="12" rx="4" fill="#64748B" stroke="#0F172A" strokeWidth="2.5" />
        </svg>
      );

    // 6. Almari Tinggi vs Almari Rendah
    case 'wardrobe-tall':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="50" y="15" width="100" height="150" rx="6" fill="#D97706" stroke="#0F172A" strokeWidth="4" />
          <line x1="100" y1="15" x2="100" y2="135" stroke="#78350F" strokeWidth="3.5" />
          {/* Handles */}
          <circle cx="92" cy="75" r="4" fill="#FEF08A" stroke="#0F172A" strokeWidth="2" />
          <circle cx="108" cy="75" r="4" fill="#FEF08A" stroke="#0F172A" strokeWidth="2" />
          {/* Bottom Drawer */}
          <rect x="58" y="138" width="84" height="20" rx="3" fill="#B45309" stroke="#0F172A" strokeWidth="2.5" />
          <rect x="92" y="145" width="16" height="5" rx="2" fill="#FEF08A" />
        </svg>
      );

    case 'wardrobe-short':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="55" y="95" width="90" height="70" rx="6" fill="#D97706" stroke="#0F172A" strokeWidth="3.5" />
          <line x1="100" y1="95" x2="100" y2="165" stroke="#78350F" strokeWidth="3" />
          <circle cx="92" cy="125" r="3.5" fill="#FEF08A" stroke="#0F172A" strokeWidth="1.5" />
          <circle cx="108" cy="125" r="3.5" fill="#FEF08A" stroke="#0F172A" strokeWidth="1.5" />
        </svg>
      );

    // 7. Pokok Kelapa Tinggi vs Pokok Pisang Rendah
    case 'tree-coconut-tall':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Tall curved trunk */}
          <path d="M100 170 C95 110 115 60 100 25" stroke="#92400E" strokeWidth="14" strokeLinecap="round" />
          {/* Coconuts */}
          <circle cx="95" cy="30" r="7" fill="#78350F" />
          <circle cx="106" cy="32" r="7" fill="#78350F" />
          {/* Coconut palm fronds */}
          <path d="M100 25 Q135 10 160 35" stroke="#15803D" strokeWidth="7" strokeLinecap="round" fill="none" />
          <path d="M100 25 Q65 10 35 35" stroke="#15803D" strokeWidth="7" strokeLinecap="round" fill="none" />
          <path d="M100 25 Q145 35 155 70" stroke="#16A34A" strokeWidth="6" strokeLinecap="round" fill="none" />
          <path d="M100 25 Q55 35 45 70" stroke="#16A34A" strokeWidth="6" strokeLinecap="round" fill="none" />
          <path d="M100 25 Q100 0 100 -5" stroke="#22C55E" strokeWidth="5" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'tree-banana-short':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Short banana tree */}
          <path d="M100 170 L100 120" stroke="#84CC16" strokeWidth="16" strokeLinecap="round" />
          {/* Broad banana leaves */}
          <path d="M100 120 Q60 100 50 130 Q75 125 100 120" fill="#22C55E" stroke="#15803D" strokeWidth="2.5" />
          <path d="M100 120 Q140 100 150 130 Q125 125 100 120" fill="#22C55E" stroke="#15803D" strokeWidth="2.5" />
          <path d="M100 120 Q100 80 85 90 Q95 105 100 120" fill="#4ADE80" stroke="#15803D" strokeWidth="2.5" />
        </svg>
      );

    // 8. Pasu Kaca Tinggi vs Rendah
    case 'vase-tall':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="100" cy="20" rx="20" ry="7" fill="#E0F2FE" stroke="#0284C7" strokeWidth="3.5" />
          <path d="M80 20 C80 60 60 120 70 160 L130 160 C140 120 120 60 120 20 Z" fill="#BAE6FD" stroke="#0284C7" strokeWidth="4" />
          <ellipse cx="100" cy="160" rx="30" ry="8" fill="#7DD3FC" stroke="#0284C7" strokeWidth="3" />
        </svg>
      );

    case 'vase-short':
      return (
        <svg viewBox="0 0 200 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="100" cy="115" rx="16" ry="5" fill="#FED7AA" stroke="#EA580C" strokeWidth="3" />
          <path d="M84 115 C84 130 70 145 75 165 L125 165 C130 145 116 130 116 115 Z" fill="#FDBA74" stroke="#EA580C" strokeWidth="3.5" />
          <ellipse cx="100" cy="165" rx="25" ry="6" fill="#FB923C" stroke="#EA580C" strokeWidth="2.5" />
        </svg>
      );

    default:
      return <div className="text-4xl text-center">⭐</div>;
  }
};
