import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Eraser, RotateCcw, CheckCircle, Sparkles, Volume2, HelpCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { speechService } from '../utils/speech';
import { TRACING_TARGETS } from '../data/curriculumData';
import { TracingTarget } from '../types';

interface WritingCanvasProps {
  onSuccess: (xpEarned: number, starsEarned: number) => void;
  textSize: string;
}

export const WritingCanvas: React.FC<WritingCanvasProps> = ({ onSuccess, textSize }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedTargetIndex, setSelectedTargetIndex] = useState(0);
  const [isDrawing, setIsDrawing] = useState(false);
  const [penColor, setPenColor] = useState('#2563EB'); // Biru standard KPM
  const [brushSize, setBrushSize] = useState(12); // Thick brush for motor skills
  const [hasDrawn, setHasDrawn] = useState(false);
  const [showGuide, setShowGuide] = useState(true);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const currentTarget: TracingTarget = TRACING_TARGETS[selectedTargetIndex];

  // Draw 3-Line Notebook guidelines and ghost letter
  const drawGuidelinesAndTarget = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Canvas background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const width = canvas.width;
    // 3-Line system coordinates
    const lineRedTop = 80;      // Garis Merah Atas
    const lineBlueMid = 140;    // Garis Biru Tengah
    const lineBlueBase = 210;   // Garis Biru Bawah (Garis Tapak)
    const lineRedDesc = 270;    // Garis Merah Ekor Bawah

    // 1. Line 1: Garis Merah Atas
    ctx.beginPath();
    ctx.strokeStyle = '#DC2626';
    ctx.lineWidth = 3;
    ctx.moveTo(20, lineRedTop);
    ctx.lineTo(width - 20, lineRedTop);
    ctx.stroke();

    // 2. Line 2: Garis Biru Tengah
    ctx.beginPath();
    ctx.strokeStyle = '#2563EB';
    ctx.lineWidth = 2.5;
    ctx.setLineDash([8, 6]);
    ctx.moveTo(20, lineBlueMid);
    ctx.lineTo(width - 20, lineBlueMid);
    ctx.stroke();
    ctx.setLineDash([]); // Reset dash

    // 3. Line 3: Garis Biru Tapak
    ctx.beginPath();
    ctx.strokeStyle = '#1D4ED8';
    ctx.lineWidth = 3.5;
    ctx.moveTo(20, lineBlueBase);
    ctx.lineTo(width - 20, lineBlueBase);
    ctx.stroke();

    // 4. Line 4: Garis Merah Ekor Bawah (untuk huruf g, j, y)
    ctx.beginPath();
    ctx.strokeStyle = '#FCA5A5';
    ctx.lineWidth = 2;
    ctx.moveTo(20, lineRedDesc);
    ctx.lineTo(width - 20, lineRedDesc);
    ctx.stroke();

    // Text labels for accessibility and visual learning
    ctx.font = 'bold 12px sans-serif';
    ctx.fillStyle = '#DC2626';
    ctx.fillText('Garis Merah Atas', 24, lineRedTop - 8);

    ctx.fillStyle = '#2563EB';
    ctx.fillText('Ruang Tengah', 24, lineBlueMid - 6);

    ctx.fillStyle = '#1D4ED8';
    ctx.fillText('Garis Tapak', 24, lineBlueBase + 16);

    // If ghost guide is enabled, render the faint template
    if (showGuide) {
      ctx.save();
      ctx.font = 'bold 130px "Comic Neue", "Lexend", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';

      // Outline ghost
      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 14;
      ctx.lineJoin = 'round';
      ctx.strokeText(currentTarget.charOrWord, width / 2, lineBlueBase);

      // Dotted center line
      ctx.strokeStyle = '#94A3B8';
      ctx.lineWidth = 4;
      ctx.setLineDash([6, 6]);
      ctx.strokeText(currentTarget.charOrWord, width / 2, lineBlueBase);

      ctx.restore();
    }
  }, [showGuide, currentTarget]);

  useEffect(() => {
    drawGuidelinesAndTarget();
    setHasDrawn(false);
    setFeedbackMessage(null);
    // Speak instruction for new target
    speechService.speak(currentTarget.instruction);
  }, [drawGuidelinesAndTarget, currentTarget]);

  // Handle Drawing events
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    setHasDrawn(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    // Scale to internal canvas resolution
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    ctx.beginPath();
    ctx.moveTo(x * scaleX, y * scaleY);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = penColor;
    ctx.lineWidth = brushSize;
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const handleClear = () => {
    speechService.playClickSound();
    drawGuidelinesAndTarget();
    setHasDrawn(false);
    setFeedbackMessage(null);
  };

  const handleVerify = () => {
    if (!hasDrawn) {
      speechService.speak('Cuba tulis atau surih huruf di dalam garisan dulu ya.');
      setFeedbackMessage('Sila tulis di atas kanvas terlebih dahulu.');
      return;
    }

    speechService.playSuccessSound();
    speechService.speak(
      `Tahniah! Tulisan kamu untuk huruf ${currentTarget.charOrWord} sangat kemas dan cantik! Teruskan usaha!`
    );

    confetti({
      particleCount: 75,
      spread: 70,
      origin: { y: 0.6 }
    });

    setFeedbackMessage(`🌟 Hebat! Murid berjaya menyurih "${currentTarget.charOrWord}" dengan sangat kemas!`);
    onSuccess(25, 2); // 25 XP, 2 Stars
  };

  return (
    <div className="bg-white rounded-3xl p-6 shadow-xl border-4 border-amber-300">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4 pb-3 border-b-2 border-slate-100">
        <div>
          <span className="inline-block bg-blue-100 text-blue-800 text-sm font-extrabold px-3 py-1 rounded-full uppercase tracking-wider mb-1">
            Modul Menulis Garis Tiga KPM
          </span>
          <h2 className={`font-black text-slate-800 ${textSize === 'extralarge' ? 'text-3xl' : 'text-2xl'}`}>
            Surih & Tulis Kemas: <span className="text-blue-600 underline">{currentTarget.charOrWord}</span>
          </h2>
        </div>

        <button
          onClick={() => speechService.speak(currentTarget.instruction)}
          className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-900 font-bold px-4 py-2 rounded-2xl shadow transition cursor-pointer"
          title="Dengar arahan menulis"
        >
          <Volume2 size={22} />
          <span>Dengar Arahan Cikgu</span>
        </button>
      </div>

      {/* Target Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4 scrollbar-thin">
        <span className="text-xs font-bold text-slate-500 uppercase shrink-0">Pilihan Huruf/Perkataan:</span>
        {TRACING_TARGETS.map((target, idx) => (
          <button
            key={target.id}
            onClick={() => {
              speechService.playClickSound();
              setSelectedTargetIndex(idx);
            }}
            className={`cursor-pointer px-4 py-2 rounded-2xl font-black text-xl transition-all shrink-0 ${
              selectedTargetIndex === idx
                ? 'bg-blue-600 text-white shadow-lg scale-105 border-2 border-blue-700'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300'
            }`}
          >
            {target.charOrWord}
          </button>
        ))}
      </div>

      {/* Teacher Instruction Card */}
      <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-4 flex items-start gap-3">
        <HelpCircle className="text-blue-600 shrink-0 mt-0.5" size={24} />
        <div>
          <p className="text-blue-950 font-bold text-lg leading-snug">{currentTarget.instruction}</p>
          <p className="text-blue-700 text-sm font-semibold mt-1">
            Petua: Perhatikan garisan merah atas dan garisan biru tapak supaya saiz huruf seimbang.
          </p>
        </div>
      </div>

      {/* Interactive 3-Line Canvas */}
      <div className="relative border-4 border-slate-800 rounded-2xl overflow-hidden bg-white shadow-inner">
        <canvas
          ref={canvasRef}
          width={650}
          height={320}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full h-72 sm:h-80 touch-none cursor-crosshair block"
        />
      </div>

      {/* Feedback message banner */}
      {feedbackMessage && (
        <div className="mt-4 p-4 rounded-2xl bg-emerald-100 border-2 border-emerald-400 text-emerald-900 font-extrabold text-center text-lg animate-bounce">
          {feedbackMessage}
        </div>
      )}

      {/* Tools Toolbar */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-4 pt-3 border-t-2 border-slate-100">
        {/* Colors and Brush */}
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-slate-700">Warna Pen:</span>
          <div className="flex items-center gap-2">
            {[
              { color: '#2563EB', name: 'Biru' },
              { color: '#DC2626', name: 'Merah' },
              { color: '#16A34A', name: 'Hijau' },
              { color: '#1E293B', name: 'Hitam Pensel' },
              { color: '#D97706', name: 'Emas' }
            ].map((c) => (
              <button
                key={c.color}
                onClick={() => {
                  speechService.playClickSound();
                  setPenColor(c.color);
                }}
                title={c.name}
                className={`w-9 h-9 rounded-full transition-transform cursor-pointer border-2 ${
                  penColor === c.color ? 'scale-125 border-slate-900 shadow-md ring-2 ring-yellow-400' : 'border-white'
                }`}
                style={{ backgroundColor: c.color }}
              />
            ))}
          </div>

          <div className="h-6 w-px bg-slate-300 mx-1" />

          {/* Saiz Mata Pen */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-600">Saiz:</span>
            {[
              { size: 8, label: 'Nipis' },
              { size: 14, label: 'Sederhana' },
              { size: 20, label: 'Tebal' }
            ].map((b) => (
              <button
                key={b.size}
                onClick={() => setBrushSize(b.size)}
                className={`cursor-pointer px-2.5 py-1 rounded-xl text-xs font-bold ${
                  brushSize === b.size ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {b.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              speechService.playClickSound();
              setShowGuide(!showGuide);
            }}
            className={`cursor-pointer px-3.5 py-2.5 rounded-2xl font-bold text-sm border-2 transition ${
              showGuide ? 'bg-amber-100 border-amber-300 text-amber-900' : 'bg-slate-100 border-slate-300 text-slate-600'
            }`}
          >
            {showGuide ? 'Sembunyi Garis Panduan' : 'Papar Garis Panduan'}
          </button>

          <button
            onClick={handleClear}
            className="cursor-pointer flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold border border-rose-300 transition"
          >
            <RotateCcw size={18} />
            <span>Padam Semula</span>
          </button>

          <button
            onClick={handleVerify}
            className="cursor-pointer flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-lg shadow-lg shadow-emerald-200 border-2 border-emerald-600 transition active:scale-95"
          >
            <CheckCircle size={24} />
            <span>Semak Tulisan!</span>
          </button>
        </div>
      </div>
    </div>
  );
};
