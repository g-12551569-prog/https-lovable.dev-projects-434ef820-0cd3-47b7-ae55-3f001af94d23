import React, { useState } from 'react';
import { Volume2, CheckCircle2, XCircle, ArrowRight, RotateCcw, Award } from 'lucide-react';
import confetti from 'canvas-confetti';
import { PRA_NOMBOR_ITEMS } from '../data/curriculumData';
import { ObjectIllustration } from './ObjectIllustrations';
import { speechService } from '../utils/speech';

interface PraNomborActivityProps {
  onSuccess: (xpEarned: number, starsEarned: number) => void;
  textSize: string;
}

export const PraNomborActivity: React.FC<PraNomborActivityProps> = ({ onSuccess, textSize }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAttribute, setSelectedAttribute] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [completedCount, setCompletedCount] = useState(0);

  const currentItem = PRA_NOMBOR_ITEMS[currentIndex];

  const handleSelect = (attribute: string) => {
    if (isAnswered) return;

    speechService.playClickSound();
    setSelectedAttribute(attribute);
    setIsAnswered(true);

    const correct = attribute === currentItem.correctAttribute;
    setIsCorrect(correct);

    if (correct) {
      speechService.playSuccessSound();
      speechService.speak(
        `Tahniah! Jawapan kamu tepat sekali. Ini adalah objek yang ${currentItem.correctAttribute}!`
      );
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
      setCompletedCount((prev) => prev + 1);
      onSuccess(20, 1);
    } else {
      speechService.playEncouragementSound();
      speechService.speak(
        `Cuba lagi ya! Perhatikan saiz dan perbezaannya dengan teliti.`
      );
    }
  };

  const handleNext = () => {
    speechService.playClickSound();
    if (currentIndex < PRA_NOMBOR_ITEMS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAttribute(null);
      setIsAnswered(false);
      setIsCorrect(false);
    } else {
      // Finished all
      speechService.playSuccessSound();
      speechService.speak('Syabas! Kamu telah menguasai semua konsep objek pra-nombor!');
    }
  };

  const handleRetry = () => {
    speechService.playClickSound();
    setSelectedAttribute(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-4 border-emerald-400">
      {/* Header and Progress */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b-2 border-slate-100">
        <div>
          <span className="inline-block bg-emerald-100 text-emerald-800 font-extrabold text-sm px-3.5 py-1 rounded-full uppercase tracking-wider mb-1">
            Matematik Pemulihan: Pra-Nombor (DSKP KPM)
          </span>
          <h2 className={`font-black text-slate-800 ${textSize === 'extralarge' ? 'text-3xl' : 'text-2xl'}`}>
            {currentItem.title}
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-xs font-bold text-slate-500 uppercase block">Kemajuan Soalan</span>
            <span className="font-extrabold text-lg text-emerald-600">
              {currentIndex + 1} / {PRA_NOMBOR_ITEMS.length}
            </span>
          </div>
          <button
            onClick={() => speechService.speak(currentItem.voiceInstruction)}
            className="flex items-center gap-2 bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold px-4 py-2.5 rounded-2xl shadow transition cursor-pointer"
            title="Dengar arahan soalan"
          >
            <Volume2 size={24} />
            <span>Dengar Arahan</span>
          </button>
        </div>
      </div>

      {/* Big Instruction Banner (High visibility for visually impaired pupils) */}
      <div className="bg-amber-50 border-3 border-amber-300 rounded-3xl p-5 mb-8 text-center shadow-sm">
        <p className="text-xs font-black uppercase tracking-wider text-amber-700 mb-1">Tugasan Murid:</p>
        <p
          className={`font-black text-slate-900 leading-snug ${
            textSize === 'extralarge' ? 'text-3xl sm:text-4xl' : 'text-2xl sm:text-3xl'
          }`}
        >
          {currentItem.instruction}
        </p>
      </div>

      {/* Two Comparison Cards side by side */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
        {/* Card A */}
        <button
          onClick={() => handleSelect(currentItem.pair.itemA.attribute)}
          disabled={isAnswered}
          className={`relative rounded-3xl p-6 transition-all duration-200 cursor-pointer flex flex-col items-center justify-between min-h-[300px] border-4 ${
            selectedAttribute === currentItem.pair.itemA.attribute
              ? isCorrect
                ? 'bg-emerald-50 border-emerald-500 ring-4 ring-emerald-300 scale-102'
                : 'bg-rose-50 border-rose-400 ring-4 ring-rose-200'
              : 'bg-slate-50 hover:bg-amber-50 border-slate-300 hover:border-amber-400 hover:shadow-xl'
          } ${isAnswered ? 'cursor-default' : ''}`}
        >
          <div className="w-full flex justify-between items-center mb-2">
            <span className="font-extrabold text-slate-500 text-sm bg-white px-3 py-1 rounded-full border border-slate-200">
              Pilihan A
            </span>
            {isAnswered && currentItem.pair.itemA.attribute === currentItem.correctAttribute && (
              <span className="flex items-center gap-1 text-emerald-600 font-bold bg-emerald-100 px-3 py-1 rounded-full">
                <CheckCircle2 size={18} /> Jawapan Betul
              </span>
            )}
          </div>

          <div className="py-4 my-auto flex justify-center">
            <ObjectIllustration type={currentItem.pair.itemA.svgType} className="w-52 h-44 drop-shadow-md" />
          </div>

          <div className="w-full mt-4">
            <span className="block text-center font-extrabold text-xl text-slate-800 bg-white py-3 rounded-2xl border-2 border-slate-200 shadow-sm">
              {currentItem.pair.itemA.name}
            </span>
          </div>
        </button>

        {/* Card B */}
        <button
          onClick={() => handleSelect(currentItem.pair.itemB.attribute)}
          disabled={isAnswered}
          className={`relative rounded-3xl p-6 transition-all duration-200 cursor-pointer flex flex-col items-center justify-between min-h-[300px] border-4 ${
            selectedAttribute === currentItem.pair.itemB.attribute
              ? isCorrect
                ? 'bg-emerald-50 border-emerald-500 ring-4 ring-emerald-300 scale-102'
                : 'bg-rose-50 border-rose-400 ring-4 ring-rose-200'
              : 'bg-slate-50 hover:bg-amber-50 border-slate-300 hover:border-amber-400 hover:shadow-xl'
          } ${isAnswered ? 'cursor-default' : ''}`}
        >
          <div className="w-full flex justify-between items-center mb-2">
            <span className="font-extrabold text-slate-500 text-sm bg-white px-3 py-1 rounded-full border border-slate-200">
              Pilihan B
            </span>
            {isAnswered && currentItem.pair.itemB.attribute === currentItem.correctAttribute && (
              <span className="flex items-center gap-1 text-emerald-600 font-bold bg-emerald-100 px-3 py-1 rounded-full">
                <CheckCircle2 size={18} /> Jawapan Betul
              </span>
            )}
          </div>

          <div className="py-4 my-auto flex justify-center">
            <ObjectIllustration type={currentItem.pair.itemB.svgType} className="w-52 h-44 drop-shadow-md" />
          </div>

          <div className="w-full mt-4">
            <span className="block text-center font-extrabold text-xl text-slate-800 bg-white py-3 rounded-2xl border-2 border-slate-200 shadow-sm">
              {currentItem.pair.itemB.name}
            </span>
          </div>
        </button>
      </div>

      {/* Answer Evaluation Banner & Next Step */}
      {isAnswered && (
        <div
          className={`p-5 rounded-3xl border-3 flex flex-wrap items-center justify-between gap-4 animate-fade-in ${
            isCorrect
              ? 'bg-emerald-100 border-emerald-400 text-emerald-950'
              : 'bg-rose-100 border-rose-400 text-rose-950'
          }`}
        >
          <div className="flex items-center gap-3">
            {isCorrect ? (
              <CheckCircle2 size={36} className="text-emerald-600 shrink-0" />
            ) : (
              <XCircle size={36} className="text-rose-600 shrink-0" />
            )}
            <div>
              <p className="font-black text-xl">
                {isCorrect ? 'Tahniah! Sangat Hebat!' : 'Cuba Lagi, Murid Pintar!'}
              </p>
              <p className="text-base font-semibold">
                {isCorrect
                  ? `Objek ini memang ${currentItem.correctAttribute.toUpperCase()}!`
                  : `Ini bukan objek yang ${currentItem.correctAttribute}. Tekan Cuba Lagi untuk pilih semula.`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {!isCorrect ? (
              <button
                onClick={handleRetry}
                className="cursor-pointer flex items-center gap-2 px-5 py-3 rounded-2xl bg-white hover:bg-slate-50 text-slate-900 font-extrabold text-base shadow border border-slate-300"
              >
                <RotateCcw size={20} />
                <span>Cuba Lagi</span>
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="cursor-pointer flex items-center gap-2 px-7 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-lg shadow-lg border-2 border-emerald-700 active:scale-95"
              >
                <span>{currentIndex < PRA_NOMBOR_ITEMS.length - 1 ? 'Soalan Seterusnya' : 'Selesai Modul'}</span>
                <ArrowRight size={22} />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
