import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { speechService } from '../utils/speech';

interface AudioSpeakerButtonProps {
  textToSpeak: string;
  label?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'primary' | 'secondary' | 'accent';
  className?: string;
  autoPlay?: boolean;
}

export const AudioSpeakerButton: React.FC<AudioSpeakerButtonProps> = ({
  textToSpeak,
  label,
  size = 'md',
  variant = 'primary',
  className = '',
}) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    speechService.playClickSound();

    if (isPlaying) {
      speechService.stop();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    speechService.speak(textToSpeak, () => {
      setIsPlaying(false);
    });
  };

  const sizeClasses = {
    sm: 'p-2 text-sm gap-1.5',
    md: 'px-4 py-2.5 text-base gap-2',
    lg: 'px-5 py-3 text-lg font-bold gap-2.5',
    xl: 'px-7 py-4 text-xl font-extrabold gap-3 shadow-lg'
  };

  const iconSizes = {
    sm: 18,
    md: 22,
    lg: 28,
    xl: 34
  };

  const variantClasses = {
    primary: 'bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white shadow-emerald-200 border-2 border-emerald-600',
    secondary: 'bg-amber-400 hover:bg-amber-500 active:scale-95 text-slate-900 shadow-amber-200 border-2 border-amber-500',
    accent: 'bg-blue-600 hover:bg-blue-700 active:scale-95 text-white shadow-blue-200 border-2 border-blue-700'
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={`Dengar sebutan: ${label || textToSpeak}`}
      title="Klik untuk dengar suara arahan cikgu"
      className={`inline-flex items-center justify-center rounded-2xl cursor-pointer transition-all duration-200 shadow-md ${variantClasses[variant]} ${sizeClasses[size]} ${
        isPlaying ? 'ring-4 ring-yellow-400 animate-pulse scale-105' : ''
      } ${className}`}
    >
      {isPlaying ? (
        <VolumeX size={iconSizes[size]} className="animate-bounce" />
      ) : (
        <Volume2 size={iconSizes[size]} className="text-current" />
      )}
      {label && <span>{label}</span>}
      <span className="sr-only">Dengar suara arahan</span>
    </button>
  );
};
