import React from 'react';
import { Eye, Type, SunMoon, Volume2, X, Check } from 'lucide-react';
import { TextSizeMode, ContrastMode, FontMode } from '../types';
import { speechService } from '../utils/speech';

interface AccessibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  textSize: TextSizeMode;
  setTextSize: (s: TextSizeMode) => void;
  contrast: ContrastMode;
  setContrast: (c: ContrastMode) => void;
  fontMode: FontMode;
  setFontMode: (f: FontMode) => void;
  autoSpeak: boolean;
  setAutoSpeak: (a: boolean) => void;
}

export const AccessibilityModal: React.FC<AccessibilityModalProps> = ({
  isOpen,
  onClose,
  textSize,
  setTextSize,
  contrast,
  setContrast,
  fontMode,
  setFontMode,
  autoSpeak,
  setAutoSpeak
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border-4 border-blue-400 overflow-hidden">
        {/* Header */}
        <div className="bg-blue-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Eye size={28} />
            <div>
              <h2 className="text-2xl font-black">Tetapan Aksesibiliti & Penglihatan</h2>
              <p className="text-xs font-semibold text-blue-100">
                Direka khas untuk kemudahan pembacaan murid pemulihan & masalah penglihatan
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              speechService.playClickSound();
              onClose();
            }}
            className="cursor-pointer p-2 rounded-full hover:bg-blue-700 transition"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* 1. Saiz Tulisan */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Type className="text-blue-600" size={22} />
              <h3 className="font-extrabold text-slate-800 text-lg">Saiz Tulisan (Pilihan Murid)</h3>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'normal', label: 'Biasa', sub: '100%', fontClass: 'text-base' },
                { id: 'large', label: 'Besar', sub: '125%', fontClass: 'text-xl' },
                { id: 'extralarge', label: 'Sangat Besar', sub: '150%', fontClass: 'text-2xl' }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => {
                    speechService.playClickSound();
                    setTextSize(opt.id as TextSizeMode);
                    speechService.speak(`Saiz tulisan ditukar kepada ${opt.label}`);
                  }}
                  className={`cursor-pointer p-4 rounded-2xl border-3 flex flex-col items-center justify-center transition ${
                    textSize === opt.id
                      ? 'bg-blue-100 border-blue-600 text-blue-900 font-black shadow-md'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 font-bold'
                  }`}
                >
                  <span className={`${opt.fontClass} font-black`}>Aa</span>
                  <span className="text-sm font-extrabold mt-1">{opt.label}</span>
                  <span className="text-xs text-slate-500 font-semibold">{opt.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Mod Kontras Visual */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <SunMoon className="text-blue-600" size={22} />
              <h3 className="font-extrabold text-slate-800 text-lg">Mod Warna & Kontras</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                onClick={() => {
                  speechService.playClickSound();
                  setContrast('default');
                }}
                className={`cursor-pointer p-3.5 rounded-2xl border-3 text-left transition ${
                  contrast === 'default'
                    ? 'border-blue-600 bg-amber-50 shadow-md ring-2 ring-blue-300'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="w-full h-8 rounded-lg bg-amber-100 border border-amber-300 mb-2 flex items-center justify-center font-bold text-slate-800 text-xs">
                  Ceria Alami
                </div>
                <span className="font-black text-sm text-slate-900 block">Standard Ceria</span>
                <span className="text-xs text-slate-500 font-semibold">Warna sekolah mesra kanak-kanak</span>
              </button>

              <button
                onClick={() => {
                  speechService.playClickSound();
                  setContrast('high-contrast-yellow');
                }}
                className={`cursor-pointer p-3.5 rounded-2xl border-3 text-left transition ${
                  contrast === 'high-contrast-yellow'
                    ? 'border-blue-600 bg-yellow-50 shadow-md ring-2 ring-blue-300'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="w-full h-8 rounded-lg bg-yellow-300 border-2 border-slate-900 mb-2 flex items-center justify-center font-black text-slate-950 text-xs">
                  Kuning Jelas
                </div>
                <span className="font-black text-sm text-slate-900 block">Kuning Kontras</span>
                <span className="text-xs text-slate-500 font-semibold">Bantuan rabun & silau mata</span>
              </button>

              <button
                onClick={() => {
                  speechService.playClickSound();
                  setContrast('high-contrast-dark');
                }}
                className={`cursor-pointer p-3.5 rounded-2xl border-3 text-left transition ${
                  contrast === 'high-contrast-dark'
                    ? 'border-blue-600 bg-slate-900 text-white shadow-md ring-2 ring-blue-300'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-900 text-white'
                }`}
              >
                <div className="w-full h-8 rounded-lg bg-black border border-yellow-400 mb-2 flex items-center justify-center font-black text-yellow-300 text-xs">
                  Gelap Terang
                </div>
                <span className="font-black text-sm block">Gelap Kontras</span>
                <span className="text-xs text-slate-400 font-semibold">Latar hitam teks kuning terang</span>
              </button>
            </div>
          </div>

          {/* 3. Pilihan Fon Mudah Baca */}
          <div>
            <h3 className="font-extrabold text-slate-800 text-lg mb-3">Jenis Fon Pembacaan</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  speechService.playClickSound();
                  setFontMode('comic');
                }}
                className={`cursor-pointer p-3.5 rounded-2xl border-3 text-left transition font-['Comic_Neue'] ${
                  fontMode === 'comic'
                    ? 'bg-amber-100 border-amber-500 text-slate-900 shadow-md'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span className="font-bold text-lg block">Comic Kanak-Kanak</span>
                <span className="text-xs text-slate-600">Bentuk bulat mesra murid sekolah rendah</span>
              </button>

              <button
                onClick={() => {
                  speechService.playClickSound();
                  setFontMode('lexend');
                }}
                className={`cursor-pointer p-3.5 rounded-2xl border-3 text-left transition font-['Lexend'] ${
                  fontMode === 'lexend'
                    ? 'bg-blue-100 border-blue-500 text-slate-900 shadow-md'
                    : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                <span className="font-bold text-lg block">Lexend Disleksia</span>
                <span className="text-xs text-slate-600">Jarak huruf jelas, elak keliru b dan d</span>
              </button>
            </div>
          </div>

          {/* 4. Suara Arahan Automatik */}
          <div className="bg-slate-100 p-4 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Volume2 className="text-blue-600" size={24} />
              <div>
                <span className="font-extrabold text-slate-800 block text-base">Suara Arahan Automatik</span>
                <span className="text-xs text-slate-600 font-semibold">
                  Sebut arahan secara automatik semasa memasuki soalan baharu
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                speechService.playClickSound();
                setAutoSpeak(!autoSpeak);
              }}
              className={`cursor-pointer w-14 h-8 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                autoSpeak ? 'bg-emerald-500' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-md transform transition-transform duration-200 ease-in-out ${
                  autoSpeak ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t-2 border-slate-200 flex justify-end">
          <button
            onClick={() => {
              speechService.playClickSound();
              onClose();
            }}
            className="cursor-pointer px-6 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-base shadow"
          >
            Simpan & Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
