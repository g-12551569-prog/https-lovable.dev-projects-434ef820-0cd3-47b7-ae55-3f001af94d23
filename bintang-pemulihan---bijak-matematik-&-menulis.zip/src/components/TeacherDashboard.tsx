import React, { useState } from 'react';
import {
  GraduationCap,
  Users,
  Printer,
  Sliders,
  CheckCircle2,
  FileText,
  Plus,
  Edit2,
  ChevronRight,
  BookOpen,
  Award
} from 'lucide-react';
import { StudentProfile, LevelType } from '../types';
import { speechService } from '../utils/speech';

interface TeacherDashboardProps {
  currentStudent: StudentProfile;
  onUpdateStudentLevel: (level: LevelType) => void;
  onSelectStudent: (student: StudentProfile) => void;
  allStudents: StudentProfile[];
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  currentStudent,
  onUpdateStudentLevel,
  onSelectStudent,
  allStudents
}) => {
  const [activeTab, setActiveTab] = useState<'pantauan' | 'lembaran' | 'dskp'>('pantauan');
  const [printWorksheetType, setPrintWorksheetType] = useState<'pra-nombor' | 'garis-tiga' | 'matematik'>('pra-nombor');

  const handlePrint = () => {
    speechService.playClickSound();
    window.print();
  };

  // KPM Remedial Constructs
  const kpmConstructs = [
    { id: 'K1', title: 'Konstruk 1: Kemahiran Pra-Nombor (Saiz & Dimensi)', status: 'Menguasai', color: 'emerald' },
    { id: 'K2', title: 'Konstruk 2: Keupayaan Membilang Objek 1 hingga 10', status: currentStudent.currentLevel !== 'tahap1' ? 'Menguasai' : 'Sedang Belajar', color: currentStudent.currentLevel !== 'tahap1' ? 'emerald' : 'amber' },
    { id: 'K3', title: 'Konstruk 3: Operasi Asas Tambah & Tolak Bergambar', status: currentStudent.currentLevel === 'tahap3' ? 'Menguasai' : 'Belum Menguasai', color: currentStudent.currentLevel === 'tahap3' ? 'emerald' : 'slate' },
    { id: 'K4', title: 'Konstruk 4: Kemahiran Menulis Berpandu Garis Tiga (KPM)', status: 'Menguasai', color: 'emerald' },
    { id: 'K5', title: 'Konstruk 5: Mengeja dan Membunyikan Suku Kata Terbuka (KV)', status: currentStudent.currentLevel !== 'tahap1' ? 'Menguasai' : 'Sedang Belajar', color: currentStudent.currentLevel !== 'tahap1' ? 'emerald' : 'amber' },
    { id: 'K6', title: 'Konstruk 6: Membina Perkataan Bermakna daripada Suku Kata', status: currentStudent.currentLevel === 'tahap3' ? 'Menguasai' : 'Belum Menguasai', color: currentStudent.currentLevel === 'tahap3' ? 'emerald' : 'slate' }
  ];

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-4 border-purple-400">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b-2 border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-purple-600 text-white flex items-center justify-center text-3xl shadow-md">
            👨🏻‍🏫
          </div>
          <div>
            <span className="bg-purple-100 text-purple-800 text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider">
              Mod Guru Pemulihan Khas KPM
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              Pusat Kawalan & Pemantauan Intervensi Murid
            </h2>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl">
          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('pantauan');
            }}
            className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm transition ${
              activeTab === 'pantauan' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            📊 Pantauan Murid
          </button>
          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('lembaran');
            }}
            className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm transition ${
              activeTab === 'lembaran' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            🖨️ Lembaran Boleh Cetak
          </button>
          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('dskp');
            }}
            className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm transition ${
              activeTab === 'dskp' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            📘 Rekod Konstruk KPM
          </button>
        </div>
      </div>

      {/* TAB 1: PANTAUAN MURID & PENETAPAN TAHAP */}
      {activeTab === 'pantauan' && (
        <div className="space-y-6">
          {/* Active Student Card */}
          <div className="bg-gradient-to-r from-purple-50 via-indigo-50 to-blue-50 border-2 border-purple-200 rounded-3xl p-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <span className="text-5xl">{currentStudent.avatar}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-2xl font-black text-slate-900">{currentStudent.name}</h3>
                    <span className="bg-purple-200 text-purple-900 font-extrabold text-xs px-2.5 py-0.5 rounded-full">
                      Murid Aktif
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-slate-600 mt-1">
                    Tahap Semasa:{' '}
                    <span className="font-extrabold text-purple-700 uppercase">
                      {currentStudent.currentLevel === 'tahap1'
                        ? 'Tahap 1: Asas (Pra-Nombor & Garis Tiga)'
                        : currentStudent.currentLevel === 'tahap2'
                        ? 'Tahap 2: Sederhana (Kira 1-10 & Suku Kata KV)'
                        : 'Tahap 3: Pengukuhan (Operasi & Perkataan)'}
                    </span>
                  </p>
                </div>
              </div>

              {/* Level Selector Buttons */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase mr-1">Tukar Tahap:</span>
                {[
                  { level: 'tahap1', label: 'Tahap 1 (Asas)' },
                  { level: 'tahap2', label: 'Tahap 2 (Sederhana)' },
                  { level: 'tahap3', label: 'Tahap 3 (Pengukuhan)' }
                ].map((lvl) => (
                  <button
                    key={lvl.level}
                    onClick={() => {
                      speechService.playClickSound();
                      onUpdateStudentLevel(lvl.level as LevelType);
                      speechService.speak(`Tahap murid telah diselaraskan ke ${lvl.label}`);
                    }}
                    className={`cursor-pointer px-3.5 py-2 rounded-xl text-xs font-black transition-all ${
                      currentStudent.currentLevel === lvl.level
                        ? 'bg-purple-600 text-white shadow-md ring-2 ring-purple-300'
                        : 'bg-white text-slate-700 hover:bg-purple-100 border border-slate-300'
                    }`}
                  >
                    {lvl.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* List of Other Students in Remedial Class */}
          <div>
            <h4 className="font-extrabold text-slate-800 text-lg mb-3">Senarai Murid Kelas Pemulihan:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {allStudents.map((st) => (
                <div
                  key={st.id}
                  onClick={() => onSelectStudent(st)}
                  className={`p-4 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between ${
                    st.id === currentStudent.id
                      ? 'bg-purple-100 border-purple-500 ring-2 ring-purple-300 shadow-md'
                      : 'bg-slate-50 border-slate-200 hover:border-purple-300 hover:bg-purple-50/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{st.avatar}</span>
                    <div>
                      <span className="font-black text-slate-900 block text-base">{st.name}</span>
                      <span className="text-xs font-semibold text-slate-500">
                        {st.currentLevel === 'tahap1' ? 'Tahap 1' : st.currentLevel === 'tahap2' ? 'Tahap 2' : 'Tahap 3'} • {st.stars} ⭐
                      </span>
                    </div>
                  </div>
                  {st.id === currentStudent.id && <CheckCircle2 size={20} className="text-purple-600" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: LEMBARAN KERJA BOLEH CETAK */}
      {activeTab === 'lembaran' && (
        <div>
          <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4 mb-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-extrabold text-amber-900 text-lg">Penjana Lembaran Latih Tubi Fizikal</h3>
              <p className="text-sm text-amber-700">
                Pilih topik latihan dan klik butang cetak untuk mencetak lembaran kerja berkualiti tinggi bagi murid.
              </p>
            </div>
            <button
              onClick={handlePrint}
              className="cursor-pointer flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-black px-6 py-3 rounded-2xl shadow-lg transition active:scale-95"
            >
              <Printer size={22} />
              <span>Cetak Lembaran Kerja Ini</span>
            </button>
          </div>

          {/* Worksheet selector */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setPrintWorksheetType('pra-nombor')}
              className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm border-2 ${
                printWorksheetType === 'pra-nombor'
                  ? 'bg-purple-600 text-white border-purple-700'
                  : 'bg-slate-100 text-slate-700 border-slate-200'
              }`}
            >
              Lembaran 1: Pra-Nombor (Tebal/Nipis & Tinggi/Rendah)
            </button>
            <button
              onClick={() => setPrintWorksheetType('garis-tiga')}
              className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm border-2 ${
                printWorksheetType === 'garis-tiga'
                  ? 'bg-purple-600 text-white border-purple-700'
                  : 'bg-slate-100 text-slate-700 border-slate-200'
              }`}
            >
              Lembaran 2: Menulis Garis Tiga (a, b, d, ibu, bola)
            </button>
            <button
              onClick={() => setPrintWorksheetType('matematik')}
              className={`cursor-pointer px-4 py-2 rounded-xl font-bold text-sm border-2 ${
                printWorksheetType === 'matematik'
                  ? 'bg-purple-600 text-white border-purple-700'
                  : 'bg-slate-100 text-slate-700 border-slate-200'
              }`}
            >
              Lembaran 3: Mengira & Suku Kata
            </button>
          </div>

          {/* Printable Worksheet Preview Box (Print-ready styling) */}
          <div className="border-4 border-slate-900 rounded-3xl p-8 bg-white text-slate-900 font-sans shadow-lg print:border-none print:shadow-none print:p-0">
            {/* Header Sekolah */}
            <div className="border-b-4 border-slate-900 pb-4 mb-6">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-black uppercase tracking-wider">
                    PROGRAM PEMULIHAN KHAS KEMENTERIAN PENDIDIKAN MALAYSIA
                  </h1>
                  <h2 className="text-lg font-bold text-slate-700">
                    LEMBARAN KERJA INTERVENSI TAHAP PENGUASAAN INDIVIDU
                  </h2>
                </div>
                <div className="text-right text-xs font-bold border-2 border-slate-900 p-2 rounded-lg">
                  <div>SKOR BINTANG:</div>
                  <div className="text-xl">⭐⭐⭐⭐⭐</div>
                </div>
              </div>

              {/* Student info inputs */}
              <div className="grid grid-cols-3 gap-4 mt-4 pt-3 border-t-2 border-slate-300 text-sm font-bold">
                <div>NAMA MURID: _______________________</div>
                <div>KELAS: ___________________________</div>
                <div>TARIKH: __________________________</div>
              </div>
            </div>

            {/* Content Based on Selected Worksheet */}
            {printWorksheetType === 'pra-nombor' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-black text-lg bg-slate-100 p-2 border-l-4 border-slate-900 mb-3">
                    Aktiviti 1: Padankan objek yang betul (Tebal & Nipis)
                  </h3>
                  <div className="grid grid-cols-2 gap-6 p-4 border-2 border-dashed border-slate-400 rounded-2xl">
                    <div className="border-2 border-slate-900 p-4 text-center rounded-xl">
                      <div className="text-4xl mb-2">📚</div>
                      <span className="font-extrabold text-base">[  ] Buku Tebal</span>
                    </div>
                    <div className="border-2 border-slate-900 p-4 text-center rounded-xl">
                      <div className="text-4xl mb-2">📄</div>
                      <span className="font-extrabold text-base">[  ] Buku Nipis</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-black text-lg bg-slate-100 p-2 border-l-4 border-slate-900 mb-3">
                    Aktiviti 2: Bulatkan objek yang TINGGI dan tandakan (X) pada objek yang RENDAH
                  </h3>
                  <div className="grid grid-cols-2 gap-6 p-4 border-2 border-dashed border-slate-400 rounded-2xl">
                    <div className="border-2 border-slate-900 p-6 text-center rounded-xl">
                      <div className="text-5xl mb-2">🌴</div>
                      <span className="font-extrabold text-base">Pokok Kelapa</span>
                    </div>
                    <div className="border-2 border-slate-900 p-6 text-center rounded-xl">
                      <div className="text-5xl mb-2">🌱</div>
                      <span className="font-extrabold text-base">Pokok Pisang Renek</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {printWorksheetType === 'garis-tiga' && (
              <div className="space-y-6">
                <h3 className="font-black text-lg bg-slate-100 p-2 border-l-4 border-slate-900 mb-3">
                  Arahan: Salin semula huruf dan perkataan di bawah mengikut panduan garisan tiga:
                </h3>

                {['a', 'b', 'd', 'ibu', 'bola'].map((item) => (
                  <div key={item} className="p-3 border-2 border-slate-300 rounded-xl">
                    <div className="flex items-center gap-6">
                      <span className="text-3xl font-black w-24 text-center">{item}</span>
                      <div className="flex-1 space-y-2">
                        {/* Red line */}
                        <div className="h-0.5 bg-red-600 w-full" />
                        {/* Blue dashed line */}
                        <div className="h-0.5 border-t-2 border-dashed border-blue-600 w-full" />
                        {/* Blue solid line */}
                        <div className="h-0.5 bg-blue-700 w-full" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {printWorksheetType === 'matematik' && (
              <div className="space-y-6">
                <h3 className="font-black text-lg bg-slate-100 p-2 border-l-4 border-slate-900 mb-3">
                  Kira bilangan objek dan tulis nombor di dalam petak:
                </h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="border-2 border-slate-900 p-4 rounded-xl flex items-center justify-between">
                    <div className="text-3xl">🍎 🍎 🍎</div>
                    <div className="w-16 h-16 border-2 border-slate-900 rounded-lg flex items-center justify-center font-bold text-2xl">
                      [   ]
                    </div>
                  </div>

                  <div className="border-2 border-slate-900 p-4 rounded-xl flex items-center justify-between">
                    <div className="text-3xl">🚗 🚗 🚗 🚗</div>
                    <div className="w-16 h-16 border-2 border-slate-900 rounded-lg flex items-center justify-center font-bold text-2xl">
                      [   ]
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Footer Tandatangan Guru */}
            <div className="mt-8 pt-4 border-t-2 border-slate-900 flex justify-between items-center text-xs font-bold">
              <div>DISEMAK OLEH GURU PEMULIHAN: ________________________</div>
              <div>TARIKH SEMAKAN: ________________________</div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: REKOD KONSTRUK DSKP KPM */}
      {activeTab === 'dskp' && (
        <div className="space-y-4">
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-4">
            <h3 className="font-black text-blue-950 text-lg">
              Senarai Semak Penguasaan Konstruk Pemulihan Khas (KPM)
            </h3>
            <p className="text-xs text-blue-800 font-semibold">
              Berdasarkan Garis Panduan Pelaksanaan Program Pemulihan Khas Kementerian Pendidikan Malaysia.
            </p>
          </div>

          <div className="space-y-3">
            {kpmConstructs.map((c) => (
              <div
                key={c.id}
                className="flex items-center justify-between p-4 rounded-2xl border-2 border-slate-200 bg-white shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <span className="font-black text-purple-700 text-base">{c.id}</span>
                  <span className="font-bold text-slate-800 text-sm sm:text-base">{c.title}</span>
                </div>
                <span
                  className={`px-3.5 py-1 rounded-full text-xs font-black ${
                    c.status === 'Menguasai'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : c.status === 'Sedang Belajar'
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {c.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
