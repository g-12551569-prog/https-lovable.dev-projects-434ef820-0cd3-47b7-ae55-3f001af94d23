import React, { useState } from 'react';
import { Trophy, Award, Gift, X, Star, Sparkles, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Badge, LeaderboardEntry } from '../types';
import { speechService } from '../utils/speech';

interface GamificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  badges: Badge[];
  leaderboard: LeaderboardEntry[];
  currentStudentStars: number;
  currentStudentXp: number;
  defaultTab?: 'lencana' | 'papan' | 'peti';
}

export const GamificationModal: React.FC<GamificationModalProps> = ({
  isOpen,
  onClose,
  badges,
  leaderboard,
  currentStudentStars,
  currentStudentXp,
  defaultTab = 'lencana'
}) => {
  const [activeTab, setActiveTab] = useState<'lencana' | 'papan' | 'peti'>(defaultTab);
  const [chestOpened, setChestOpened] = useState(false);
  const [chestPrize, setChestPrize] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleOpenChest = () => {
    speechService.playStarSound();
    speechService.playSuccessSound();
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.5 }
    });
    setChestOpened(true);
    setChestPrize('Pelekat Emas: "Jaguh Matematik & Tulisan Terbaik Sekolah 2026" 🌟👑');
    speechService.speak('Tahniah! Kamu telah membuka Peti Harta Karun Pemulihan!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border-4 border-amber-400 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 p-5 flex items-center justify-between border-b-4 border-amber-500">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🏆</span>
            <div>
              <h2 className="text-2xl font-black text-slate-900 leading-tight">Zon Gamifikasi & Ganjaran</h2>
              <p className="text-sm font-bold text-amber-950">
                Kumpul Bintang Kejayaan & Bersaing Secara Sihat Bersama Rakan!
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              speechService.playClickSound();
              onClose();
            }}
            className="cursor-pointer p-2 rounded-full bg-white/70 hover:bg-white text-slate-800 transition"
          >
            <X size={26} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b-2 border-slate-200 bg-slate-50 p-2 gap-2">
          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('lencana');
            }}
            className={`cursor-pointer flex-1 py-3 px-4 rounded-2xl font-black text-base flex items-center justify-center gap-2 transition ${
              activeTab === 'lencana'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Award size={22} />
            <span>Lencana ({badges.filter((b) => b.unlocked).length}/{badges.length})</span>
          </button>

          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('papan');
            }}
            className={`cursor-pointer flex-1 py-3 px-4 rounded-2xl font-black text-base flex items-center justify-center gap-2 transition ${
              activeTab === 'papan'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Trophy size={22} />
            <span>Papan Pendahulu Kelas</span>
          </button>

          <button
            onClick={() => {
              speechService.playClickSound();
              setActiveTab('peti');
            }}
            className={`cursor-pointer flex-1 py-3 px-4 rounded-2xl font-black text-base flex items-center justify-center gap-2 transition ${
              activeTab === 'peti'
                ? 'bg-amber-400 text-slate-950 shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Gift size={22} />
            <span>Peti Misteri</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {/* TAB 1: LENCANA */}
          {activeTab === 'lencana' && (
            <div>
              <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4 mb-4 flex items-center justify-between">
                <div>
                  <span className="font-extrabold text-amber-900 block text-lg">Koleksi Lencana Kejayaan</span>
                  <span className="text-sm text-amber-700 font-semibold">
                    Setiap modul yang kamu selesaikan membuka lencana khas!
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-amber-400 text-slate-950 font-black px-4 py-2 rounded-2xl">
                  <Star size={20} className="fill-current text-amber-900" />
                  <span>{currentStudentStars} Bintang</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {badges.map((badge) => (
                  <div
                    key={badge.id}
                    className={`rounded-2xl p-4 border-3 flex items-start gap-4 transition ${
                      badge.unlocked
                        ? 'bg-gradient-to-br from-amber-50 to-emerald-50 border-emerald-400 shadow-md'
                        : 'bg-slate-50 border-dashed border-slate-300 opacity-60'
                    }`}
                  >
                    <div
                      className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shrink-0 shadow-inner ${
                        badge.unlocked ? 'bg-amber-300 border-2 border-amber-500' : 'bg-slate-200 text-slate-400'
                      }`}
                    >
                      {badge.unlocked ? badge.icon : '🔒'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-black text-slate-900 text-base">{badge.title}</h4>
                        {badge.unlocked && (
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                            Dibuka
                          </span>
                        )}
                      </div>
                      <p className="text-slate-600 font-medium text-xs mt-1 leading-snug">{badge.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: PAPAN PENDAHULU */}
          {activeTab === 'papan' && (
            <div>
              {/* Podium for top 3 */}
              <div className="bg-gradient-to-b from-blue-50 to-indigo-50 rounded-2xl p-6 border-2 border-indigo-200 mb-6 text-center">
                <span className="text-xs font-black uppercase text-indigo-700 tracking-wider">
                  Podium Juara Kelas Pemulihan Khas
                </span>
                <div className="flex justify-center items-end gap-3 sm:gap-6 mt-4">
                  {/* Rank 2 */}
                  <div className="flex flex-col items-center">
                    <span className="text-3xl mb-1">🥈</span>
                    <span className="text-2xl">{leaderboard[1]?.avatar || '🧕🏼'}</span>
                    <span className="font-black text-sm text-slate-800 mt-1">{leaderboard[1]?.name || 'Nurul'}</span>
                    <span className="text-xs font-bold text-slate-500">{leaderboard[1]?.xp || 520} XP</span>
                    <div className="w-20 sm:w-24 h-20 bg-slate-300 rounded-t-xl flex items-center justify-center text-slate-700 font-black text-xl mt-2">
                      2
                    </div>
                  </div>

                  {/* Rank 1 */}
                  <div className="flex flex-col items-center">
                    <span className="text-4xl mb-1 animate-bounce">👑</span>
                    <span className="text-3xl">{leaderboard[0]?.avatar || '👦🏽'}</span>
                    <span className="font-black text-base text-slate-900 mt-1">{leaderboard[0]?.name || 'Daniel'}</span>
                    <span className="text-xs font-bold text-amber-700">{leaderboard[0]?.xp || 580} XP</span>
                    <div className="w-24 sm:w-28 h-28 bg-amber-400 rounded-t-xl flex items-center justify-center text-amber-950 font-black text-2xl mt-2 border-t-4 border-amber-500 shadow-md">
                      1
                    </div>
                  </div>

                  {/* Rank 3 */}
                  <div className="flex flex-col items-center">
                    <span className="text-3xl mb-1">🥉</span>
                    <span className="text-2xl">{leaderboard[2]?.avatar || '🧒🏻'}</span>
                    <span className="font-black text-sm text-slate-800 mt-1">{leaderboard[2]?.name || 'Haziq'}</span>
                    <span className="text-xs font-bold text-slate-500">{leaderboard[2]?.xp || 440} XP</span>
                    <div className="w-20 sm:w-24 h-16 bg-amber-700/30 rounded-t-xl flex items-center justify-center text-amber-900 font-black text-xl mt-2">
                      3
                    </div>
                  </div>
                </div>
              </div>

              {/* Full Leaderboard list */}
              <div className="space-y-2">
                {leaderboard.map((student, idx) => (
                  <div
                    key={student.id}
                    className={`flex items-center justify-between p-3.5 rounded-2xl border-2 transition ${
                      student.isCurrentStudent
                        ? 'bg-amber-100 border-amber-400 font-bold ring-2 ring-yellow-400 shadow-sm'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 text-center font-black text-slate-700 text-lg">#{idx + 1}</span>
                      <span className="text-3xl">{student.avatar}</span>
                      <div>
                        <span className="font-extrabold text-slate-900 block leading-tight">{student.name}</span>
                        <span className="text-xs font-semibold text-slate-500">{student.levelTitle}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                        <Star size={16} className="fill-current" />
                        <span>{student.isCurrentStudent ? currentStudentStars : student.stars}</span>
                      </div>
                      <div className="bg-slate-100 px-3 py-1 rounded-xl text-slate-800 font-black text-sm">
                        {student.isCurrentStudent ? currentStudentXp : student.xp} XP
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PETI HARTA KARUN */}
          {activeTab === 'peti' && (
            <div className="text-center py-6">
              <div className="max-w-md mx-auto">
                <div className="text-8xl mb-4 animate-pulse">{chestOpened ? '🎁' : '🧰'}</div>
                <h3 className="font-black text-2xl text-slate-900 mb-2">Peti Hadiah Misteri Pemulihan</h3>
                <p className="text-slate-600 font-medium mb-6">
                  Buka peti ini untuk menerima pelekat ganjaran dan pujian khas daripada Guru Pemulihan!
                </p>

                {!chestOpened ? (
                  <button
                    onClick={handleOpenChest}
                    className="cursor-pointer px-8 py-4 rounded-3xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-black text-2xl shadow-xl border-4 border-amber-500 hover:scale-105 active:scale-95 transition-all"
                  >
                    Buka Peti Hadiah Sekarang! ✨
                  </button>
                ) : (
                  <div className="bg-amber-100 border-3 border-amber-400 rounded-3xl p-6 animate-scale-in">
                    <Sparkles className="mx-auto text-amber-600 mb-2" size={36} />
                    <h4 className="font-black text-2xl text-amber-950 mb-2">Tahniah Murid Pintar!</h4>
                    <p className="font-bold text-lg text-emerald-800">{chestPrize}</p>
                    <p className="text-sm font-semibold text-slate-600 mt-3">
                      "Guru bangga dengan usaha dan ketekunan kamu dalam menguasai Matematik dan Menulis!"
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
